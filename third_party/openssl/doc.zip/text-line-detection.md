---
title: "A Segmentation-Based Text-Line Detection Network for Character-Recognition Systems"
subtitle: "An effective detector for curved and narrowly-spaced text lines"
author: "[Author]"
date: "2026"
---

# Abstract {-}

Text-line detection is the front-end stage of almost every character-recognition (optical character recognition, OCR) system: if a line is missed, merged with a neighbour, or only partially localised, no downstream recogniser can recover the lost information. This thesis studies text-line detection in the specific context of building a complete recognition system, and proposes a detector that follows the segmentation-based design adopted by widely-used engineering toolkits such as PaddleOCR and ModelScope, while introducing a small number of carefully-motivated modifications that target two failure modes these systems struggle with: **curved text lines** and **narrowly-spaced text lines**.

The proposed network keeps the now-standard differentiable-binarization (DB) pipeline — a ResNet backbone, a multi-scale feature neck, and a head that predicts a probability map and a threshold map — but augments it in four places. In the feature-extraction section (Chapter 2.1) we (i) insert deformable convolutions into the deeper backbone stages so that the receptive field can follow the curvature of a text line, and (ii) replace the plain feature-pyramid summation with an attention-based adaptive scale-fusion neck so that each spatial location selects the scale that best represents the local stroke width. In the label-generation and post-processing section (Chapter 2.2) we (iii) replace the fixed shrink ratio used to generate training masks with an adaptive shrink ratio that depends on the local inter-line gap, and (iv) add an auxiliary separation map that is learned jointly with the probability map and is used during post-processing to split lines that would otherwise be merged.

We build an end-to-end recognition system around the detector, describe its implementation, and evaluate it against representative prior methods — EAST, PSENet, PAN, DB and DB++ — on the public Total-Text, CTW1500 and ICDAR-2015 benchmarks and on a document-style dense-line set. The detector reaches an F-measure of 87.1% on Total-Text and 86.1% on CTW1500, improving on the DB baseline by 2.4 and 2.7 points respectively, and the improvement is concentrated, as intended, on curved and narrowly-spaced lines: on the narrow-spacing subset the F-measure rises from 81.5% to 89.2%. An ablation study isolates the contribution of each of the four modifications, and a runtime analysis confirms that the additions cost only a modest reduction in throughput.

A central design principle, maintained throughout, is restraint. Each of the four modifications is a *strict generalisation* of the baseline — it reduces exactly to the standard DB behaviour under a trivial setting of its parameters — so none of them can degrade the cases the baseline already handles, and each is justified by the precise mechanism of the failure it targets rather than by an appeal to additional capacity. We deliberately do not introduce a new shape representation or a costly post-processing stage; the detector remains a drop-in replacement for the detection stage of a standard PaddleOCR- or ModelScope-style system. The experiments bear out the restraint: an error-type breakdown shows that the gains come almost entirely from a two-thirds reduction in line *merges*, with misses and splits essentially unchanged, and an end-to-end measurement shows the detection improvement converting into a 4.6-point increase in correctly-recognised lines. The thesis thus contributes not only a more capable text-line detector but a worked example of a disciplined methodology for improving a mature component on its hardest cases without destabilising it on its easy ones.

\newpage

# Chapter 1. Prior Work and Problem Formulation

This chapter sets up the rest of the thesis. It explains the role text-line detection plays inside a character-recognition system and why the quality of that one stage so strongly determines the quality of the whole; it surveys the two families of deep text detectors and locates the segmentation-based, differentiable-binarization design that this thesis builds upon; it analyses, in detail, the two specific situations in which that design tends to fail — curved lines and narrowly-spaced lines — and traces each failure to a concrete assumption in the design rather than to a general shortage of model capacity; and it states the detection problem and its evaluation precisely enough that the modifications of Chapter 2 and the experiments of Chapter 3 can be judged against it. The reference numbers cited throughout (numbers 10 and above) point to the bibliography at the end of the thesis. Throughout the chapter the goal is to make the eventual contribution legible as the closing of a specific, well-identified gap, not as a general-purpose improvement.

## 1.1 Background: the role of text-line detection in a recognition system

A character-recognition system converts an image of text into a machine-readable character string. Although the end goal is the recognised string, virtually all modern systems decompose the task into two cooperating stages: a **detector** that localises the regions of the image that contain text, and a **recogniser** that reads the characters inside each localised region [10]. In a typical two-stage pipeline the detector outputs a set of text-line regions (polygons or rotated boxes), each region is cropped and geometrically rectified, and the rectified crop is passed to a sequence recogniser such as the convolutional-recurrent network (CRNN) [39]. Figure 1.1 shows this arrangement and highlights the stage that this thesis is concerned with.

![Figure 1.1. The character-recognition pipeline. Detection is the front-end stage studied in this thesis; every later stage depends on the quality of its output.](figures/fig1_pipeline.png){width=100%}

The detector occupies a privileged but unforgiving position in this pipeline. It is privileged because it determines the unit of recognition — almost all practical systems recognise one text *line* at a time, so the detector implicitly defines what a "line" is. It is unforgiving because its errors are not recoverable downstream: a line that is missed produces no output at all, a line that is split produces two truncated fragments, and — the case that motivates much of this thesis — two lines that are *merged* produce a single region that the recogniser will read as one nonsensical line. The cost of a detection error is therefore disproportionately high, and detection quality is frequently the dominant factor in the end-to-end accuracy of a recognition system [10][40].

Two operating regimes are usually distinguished. In the **document** regime the input is a scanned or photographed page; lines are numerous, roughly parallel, often densely packed, and frequently separated by very small inter-line gaps. In the **scene** regime the input is a natural photograph; lines are fewer but may be arbitrarily oriented, perspective-distorted, or **curved** (for example, text printed around a logo or along a curved sign) [44][45]. A detector intended for a general recognition system must cope with both regimes, and in practice the two regimes stress *different* parts of a detector: the scene regime stresses the ability to represent non-rectangular shapes, while the document regime stresses the ability to separate adjacent instances. The method developed in this thesis is designed with both stresses in mind.

It is worth dwelling on why the two-stage decomposition — detect, then recognise — has become near-universal, because the reasons explain why detection quality matters so much. An alternative would be to recognise characters directly from the whole image without an explicit detection stage, but this founders on two facts. First, the number and arrangement of text instances in an image is unknown and highly variable, so a recogniser operating on the whole image would have to solve localisation implicitly anyway. Second, sequence recognisers such as CRNN [39] are trained on tightly-cropped, geometrically-normalised single lines of roughly constant height; presented with a whole page they have neither the spatial resolution nor the inductive bias to read it. The detector therefore performs an indispensable service: it reduces the unconstrained two-dimensional reading problem to a collection of one-dimensional sequence-recognition problems, each on a normalised crop of known scale and orientation. Everything the recogniser does is conditioned on the detector having drawn the right boundary around the right pixels.

This conditioning is the source of the asymmetry in error cost noted above. A recogniser error is local: misreading one character in a line corrupts one character of output. A detector error is structural: it changes the *set* of lines that are read at all. The three structural error types differ in their downstream consequences. A **miss** (false negative) deletes a whole line from the output and is the most damaging in information-retrieval terms, because the lost content cannot be inferred from what remains. A **split** fragments one line into two crops, each of which the recogniser reads as a truncated string; the content survives but is broken across outputs and any line-level post-processing (for example, key–value extraction in a form) is disrupted. A **merge** is the most insidious, because it produces a confident but wrong output: handed a crop that contains two physical lines stacked vertically, the recogniser — which assumes a single horizontal sequence — produces one string interleaving or concatenating the two, matching neither. Because merges arise specifically from small inter-line gaps, and because they are common in exactly the dense documents that recognition systems are most often deployed to read, they are a central concern of this thesis.

Historically, line detection in classical OCR for clean printed pages was solved by hand-engineered methods: binarisation followed by horizontal projection profiles, connected-component analysis, and morphological grouping. These methods are fast and remain useful for clean, axis-aligned documents, but they degrade sharply under the conditions a modern system must tolerate — low contrast, complex backgrounds, perspective, curvature, and mixed scripts. The deep-learning era replaced the hand-engineered pipeline with learned detectors [10][11], and it is within this learned-detector setting that the present work sits. The remainder of the chapter surveys that setting and locates within it the specific, narrow gap this thesis aims to close.

## 1.2 A taxonomy of text-line detection methods

Research on text detection in the deep-learning era is conventionally divided into two families [10][11], shown in Figure 1.2: methods that treat detection as a **regression** problem and methods that treat it as a **segmentation** problem.

![Figure 1.2. A taxonomy of deep text-detection methods. The differentiable-binarization (DB) family, used by PaddleOCR, is the segmentation-based baseline adopted in this thesis.](figures/fig1_taxonomy.png){width=100%}

### 1.2.1 Regression-based methods

Regression-based methods adapt general-purpose object detectors to text by directly predicting the coordinates of a bounding box, a rotated box, or a quadrilateral for each text instance. The connectionist text-proposal network (CTPN) [12] detects sequences of fixed-width vertical "anchors" and links them into horizontal lines using a recurrent connection; it is accurate for horizontal document text but cannot represent oriented or curved lines. TextBoxes [13] and its successor TextBoxes++ [14] extend the single-shot detector (SSD) framework with long, text-shaped default boxes and, in the case of TextBoxes++, with quadrilateral regression for oriented text. EAST [15] dispenses with anchors and proposals entirely and directly regresses, for every pixel, the offsets to the four edges (or vertices) of the enclosing box together with a rotation angle, yielding a fast and elegant detector for multi-oriented text. SegLink [16] decomposes text into small oriented "segments" and learns the links between neighbouring segments so that they can be grouped into lines.

The defining limitation of the regression family is geometric. Because the output is a box or a fixed-vertex quadrilateral, these methods represent a text line by a small, fixed number of parameters. This is adequate for straight lines but fundamentally mismatched to curved text: as Figure 1.3(a) illustrates, the tightest axis-aligned or even rotated box around a curved line contains a large fraction of background, and a four-point quadrilateral cannot follow the curve at all [17][45]. Increasing the number of regressed vertices helps but reintroduces the ordering and matching difficulties that segmentation avoids.

It is instructive to trace this limitation to its root, because doing so motivates the choice of a segmentation baseline. Regression detectors predict a fixed-length parameter vector per instance — four numbers for an axis-aligned box, five for a rotated box, eight for a quadrilateral. The expressive power of the representation is fixed in advance and cannot adapt to the shape actually present. A gently curved line of text traces a smooth arc whose faithful description requires either many vertices or a parametric curve; forcing it into a four- or eight-number box necessarily incurs representation error, and that error is *systematic* — it does not vanish with more training data, because it is a property of the output format rather than of the learned weights. A second, related difficulty is vertex ordering. As soon as a method predicts more than four points to chase a curve, it must decide which predicted point corresponds to which ground-truth point, and this correspondence is ambiguous for symmetric or near-symmetric shapes; the resulting label-assignment noise degrades training. Methods such as TextSnake [17] sidestep ordering by representing a line as a sequence of disks along its centre line, and FCENet [24] sidesteps it by regressing Fourier coefficients of the contour rather than raw vertices — both are best understood as attempts to give regression a shape vocabulary rich enough for curves, and both move the family closer to the per-pixel flexibility that segmentation has natively. For a system that must handle both straight document lines and curved scene lines without switching representations, beginning from a per-pixel segmentation formulation is the more parsimonious choice, and it is the choice made here.

![Figure 1.3. The two failure modes that motivate this thesis. (a) A curved line cannot be tightly enclosed by a box or a four-point quadrilateral. (b) When lines are separated by a very small gap, their pixel regions touch and a segmentation network tends to merge them into a single instance.](figures/fig1_challenges.png){width=100%}

### 1.2.2 Segmentation-based methods

Segmentation-based methods instead classify every pixel as text or non-text, producing a dense map from which text regions are extracted by post-processing. Because the prediction is per-pixel, an instance of any shape — straight, oriented, or curved — is represented naturally, which is why this family dominates curved-text benchmarks [17][19][24]. The price is *instance separation*: a raw text/non-text map does not, by itself, say which pixels belong to which line, and neighbouring lines whose pixel regions touch are easily merged (Figure 1.3(b)).

The history of the segmentation family is largely a history of solutions to this separation problem. Building on fully-convolutional segmentation [30][31][32], PixelLink [18] predicts, in addition to a text/non-text map, eight link maps that indicate whether each pixel is connected to each of its neighbours; instances are then recovered by connected-component analysis on the "linked" pixels. PSENet [19] trains the network to predict several *shrunk* versions of each text region (kernels) at decreasing scales, and recovers instances by progressively expanding the smallest, well-separated kernels — the progressive scale-expansion algorithm. PAN [20] keeps a single shrunk kernel but learns a pixel-embedding so that pixels of the same instance are close in embedding space and pixels of different instances are far apart, then aggregates pixels to kernels by embedding distance. TextSnake [17] represents a line as a sequence of overlapping disks along a centre line, which is well-suited to curves. CRAFT [23] takes a complementary route, predicting per-character region scores and inter-character affinity scores and grouping characters into lines.

A further group of methods is worth describing because it shows how much effort the field has invested specifically in the *shape* of curved text, and therefore how the present work — which addresses shape with a single, cheap deformable-convolution change rather than a new representation — sits relative to them. TextField [27] predicts, for each text pixel, a two-dimensional direction field pointing toward the nearest text boundary; the field's discontinuities mark instance boundaries, and morphological post-processing on the field recovers the instances, which handles both curvature and a degree of separation. DRRG [25] builds local text components and reasons about their relationships with a graph convolutional network, grouping components into lines by learned relational edges; it is accurate on curves but heavy. ContourNet [26] predicts text contours through a pair of orthogonal one-dimensional response maps designed to suppress false positives along the contour, improving the precision of curved-text boundaries. FCENet [24] represents each contour in the Fourier domain, regressing a fixed number of Fourier coefficients per instance; because any closed contour has a Fourier series, a modest number of coefficients reconstructs a smooth curve, which gives regression-style efficiency with segmentation-style shape flexibility. The common thread across TextField, DRRG, ContourNet and FCENet is that each introduces a *new representation* of contour shape, and each pays for it either in post-processing complexity (the graph reasoning of DRRG, the morphology of TextField) or in a new output parameterisation that must be learned and decoded (the Fourier coefficients of FCENet). The design philosophy of this thesis is deliberately more conservative: rather than introduce a new shape representation, we keep DB's per-pixel map — which already represents arbitrary shapes natively — and merely let the *feature* that feeds it follow curvature, via deformable convolution. This buys most of the curved-line benefit at a fraction of the conceptual and computational cost, which is the appropriate trade for a detector intended to run as the front end of a deployed system.

The method that has become the de-facto industrial standard, and the one this thesis builds on, is the **differentiable-binarization** network, DBNet [21]. DBNet observes that the expensive and non-differentiable step in segmentation post-processing is the *binarization* of the probability map, and replaces the hard threshold with a learned, differentiable approximation (described in detail in Chapter 2). The network predicts both a probability map and a per-pixel threshold map, combines them through a differentiable binarization function, and is trained end-to-end; instances are then recovered very cheaply by thresholding and a single polygon-dilation step. Its successor, DB++ [22], adds an adaptive scale-fusion module to the neck and improves accuracy at essentially the same speed. DBNet and DB++ are the detection backbone of the PaddleOCR PP-OCR system [40][41][42] and of comparable detectors offered through the ModelScope model hub, and their combination of accuracy, speed and simplicity is the reason we adopt the DB pipeline as our starting point.

The separation strategies above are worth comparing directly, because the choice among them is precisely the design axis this thesis revisits. PixelLink's link maps [18] are expressive but brittle: a single mispredicted link between two close lines fuses them, and the eight-way link prediction adds eight output channels that must themselves be learned. PSENet's progressive scale expansion [19] is robust — the smallest kernels are well-separated by construction — but it is slow, because expansion is an iterative, sequential procedure, and the kernel scales are fixed hyperparameters that do not adapt to local spacing. PAN's learned embedding [20] is fast and elegant, but the margin that pushes different instances apart in embedding space is a single global scalar, so it cannot tighten its separation criterion only where lines are close. DB's shrink-and-dilate scheme [21] is the simplest and fastest of all, which is why it dominates in deployment, but as we argue in Section 1.3.2 its single global shrink ratio shares exactly the "global margin" weakness of PAN: it applies the same separation effort everywhere regardless of how close any particular pair of lines actually is. The recurring pattern across the whole family is that separation is governed by a *global* parameter, and the recurring failure is therefore *local*: it appears precisely where the local geometry — a narrow gap — violates what the global parameter assumed. This observation is the conceptual seed of improvements 3 and 4 in Chapter 2, both of which make the separation effort depend on local spacing rather than on a global constant.

### 1.2.3 Components shared across modern detectors

Independently of the family, modern detectors share a set of building blocks that will recur throughout this thesis. The **backbone** is almost always a residual network (ResNet) [28], which provides a hierarchy of feature maps at strides 4, 8, 16 and 32. A **feature-pyramid neck** [29] fuses these multi-scale maps so that both small and large text can be represented in a single high-resolution feature. Two enhancements to the basic convolution are particularly relevant to us: **deformable convolution** [33][34], which learns spatial offsets for its sampling grid and can therefore adapt its receptive field to non-rectangular structures, and **attention modules** [35][36], which re-weight features by channel or by spatial location. Training uses batch normalisation [37] and the Adam optimiser [38]. These components are not novel, and the modifications proposed in Chapter 2 deliberately re-use them rather than inventing new primitives; the contribution lies in *where* and *why* they are applied.

The reliance on established components is a deliberate methodological commitment rather than a convenience. Each block above has been validated across a wide range of vision tasks, so its behaviour, failure modes and cost are well understood; building from such blocks means that when a modification helps, the help can be attributed to the *placement and purpose* of a known mechanism rather than to an opaque new primitive whose own reliability would itself be in question. The residual backbone is chosen because its multi-stride hierarchy is exactly what a multi-scale text problem needs and because pre-trained weights are readily available; the feature pyramid because it is the standard remedy for scale variation; deformable convolution and attention because they are the standard, well-characterised tools for, respectively, non-rectangular receptive fields and content-dependent re-weighting — which are precisely the two capabilities the curved-line and narrow-gap failures call for. The thesis therefore reads, by design, as a sequence of well-understood tools applied to well-identified problems, which is the property that makes its claims easy to audit and its modifications safe to adopt.

## 1.3 Analysis of the limitations of prior methods

Table 1.1 summarises the families discussed above against the two criteria that matter most for a general recognition system: the ability to represent **curved** lines and the ability to **separate adjacent** lines. The table makes the gap that this thesis addresses explicit. Regression methods, by construction, cannot represent curves well; among segmentation methods, those designed for curves (PSENet, PAN, DB) handle arbitrary shapes but still rely on a *single, global* shrink ratio when generating training masks and a *single, global* dilation when recovering instances — a design that, as we analyse below, is exactly what fails when lines are close together.

**Table 1.1. A comparison of representative detection families.** ("Curved" = native support for curved lines; "Separation" = mechanism for separating touching instances.)

| Method | Family | Curved | Separation mechanism | Main limitation |
|---|---|---|---|---|
| CTPN [12] | regression | no | none (assumes horizontal) | horizontal text only |
| EAST [15] | regression | no | per-pixel box regression | boxes only; struggles on long/curved lines |
| TextBoxes++ [14] | regression | weak | quadrilateral regression | fixed vertex count |
| PixelLink [18] | segmentation | yes | 8-neighbour link maps | link errors merge instances |
| PSENet [19] | segmentation | yes | progressive scale expansion | slow; fixed kernel scales |
| PAN [20] | segmentation | yes | learned pixel embedding | embedding margin is global |
| DB / DB++ [21][22] | segmentation | yes | fixed shrink + fixed dilation | global ratio fails on narrow gaps |
| **Proposed** | segmentation | **yes** | **adaptive shrink + separation map** | — |

### 1.3.1 Curved lines

As discussed, curved lines are intrinsically difficult for regression methods and are the principal reason segmentation methods are preferred for general recognition [17][45]. However, even within the segmentation family, a standard ResNet+FPN feature extractor is built almost entirely from square convolution kernels whose sampling grid is axis-aligned. Near a sharply curved line the locally "correct" receptive field is itself curved, and an axis-aligned kernel must either include background or miss part of the stroke. Deformable convolution [33][34] was introduced precisely to let the sampling grid deform, and it has been shown to help on oriented and curved text [22]; we exploit this in Chapter 2.1.

It is worth being precise about *why* an axis-aligned receptive field hurts a per-pixel segmentation network, since the per-pixel output already represents curves natively and one might think the feature extractor is therefore irrelevant. The issue is not the output representation but the *evidence* each output pixel can gather. The probability assigned to a pixel on a curved stroke is computed from a receptive field centred on that pixel, and a deep, square receptive field straddling a tight curve necessarily takes in background on the convex side and adjacent text on the concave side. The background dilutes the text evidence and the adjacent text confuses the instance assignment, so the network's confidence on curved strokes is systematically lower and noisier than on straight ones. This shows up at evaluation as curved lines that fall just below the IoU threshold — partially localised rather than wholly missed — which is precisely the kind of error a deformable receptive field, able to sample *along* the stroke, is positioned to fix. The effect is concentrated in the deep stages, where the receptive field is large enough to span a curve's bend, which is the reason improvement 1 is applied there and not in the shallow stages.

### 1.3.2 Narrowly-spaced lines

The narrow-spacing failure is more subtle and is, in our view, under-addressed by the standard DB pipeline. To separate touching instances, DB does not learn to segment the *full* text region; it learns to segment a *shrunk* version of each region — the polygon is contracted inward by an offset computed with the Vatti clipping rule [49] using a fixed shrink ratio (typically $r = 0.4$). Shrinking opens a gap between the masks of adjacent lines so that, after thresholding, they form separate connected components; the full region is then recovered by dilating each component back out by a matching offset during post-processing.

This works well when lines are well-separated, but it has a built-in weakness when they are not. The shrink offset is computed from the *area and perimeter of each line individually* and is blind to how close its neighbours are. When two lines are separated by a gap smaller than roughly twice the shrink offset, even the shrunk masks remain within one connected component, the two lines are never separated, and no amount of careful dilation downstream can undo the merge. One could shrink more aggressively (use a smaller $r$), but a globally smaller ratio erodes thin or short lines elsewhere in the image and harms recall. The fixed, global, neighbour-blind shrink ratio is therefore a genuine design limitation, not merely a tuning issue, and it is the target of two of our four modifications (the adaptive shrink ratio of Chapter 2.2 and the auxiliary separation map). To our knowledge the existing PaddleOCR/ModelScope DB detectors retain the fixed ratio, so improving exactly this part of the pipeline is both well-motivated and practically useful.

The reason this limitation persists in deployed systems, rather than having been tuned away, is instructive and reinforces that it is structural. A single global shrink ratio is a one-dimensional knob that must serve two opposing demands at once: it must be small enough to open gaps between the closest lines in the corpus and large enough to keep the thinnest and shortest lines from being eroded into fragments. In any corpus that contains both dense passages and small or thin text — which is to say, in any realistic document corpus — no single value satisfies both demands, and the tuned compromise simply trades merges in the dense regions against splits and misses among the thin text. The benchmark-average F-measure, which pools all lines together, hides this trade because the densely-spaced lines are a minority of instances; a practitioner tuning on the average therefore has little signal pointing at the narrow-spacing failure, and the default $r=0.4$ survives. Making the ratio a function of the *local* gap, as improvement 3 does, dissolves the conflict rather than compromising it: aggressive where lines are close, gentle where they are not. This is why we regard the fix as addressing a real gap in the standard pipeline rather than substituting one global compromise for another.

## 1.4 Problem formulation

We now state the problem precisely. Let $I \in \mathbb{R}^{H\times W\times 3}$ be an input image. The ground truth is a set of text lines $\mathcal{G} = \{G_1, \dots, G_M\}$, where each $G_m$ is a polygon (an ordered list of vertices) enclosing one line of text. A text-line detector is a function

$$ f_\theta : I \;\longmapsto\; \widehat{\mathcal{G}} = \{\widehat{G}_1, \dots, \widehat{G}_N\}, \qquad \text{(1.1)} $$

parameterised by network weights $\theta$, that predicts a set of polygons $\widehat{\mathcal{G}}$. A predicted polygon $\widehat{G}_n$ is counted as correct (a true positive) if its intersection-over-union with some unmatched ground-truth polygon exceeds a threshold $\tau$ (we use $\tau = 0.5$):

$$ \mathrm{IoU}(\widehat{G}_n, G_m) \;=\; \frac{\operatorname{area}(\widehat{G}_n \cap G_m)}{\operatorname{area}(\widehat{G}_n \cup G_m)} \;>\; \tau . \qquad \text{(1.2)} $$

Writing $TP$, $FP$ and $FN$ for the numbers of true positives, false positives and false negatives over the whole test set, detection quality is summarised by precision, recall and their harmonic mean (the F-measure):

$$ P = \frac{TP}{TP+FP}, \qquad R = \frac{TP}{TP+FN}, \qquad F = \frac{2PR}{P+R}. \qquad \text{(1.3)} $$

The objective of this thesis is to design $f_\theta$ so as to maximise $F$ **subject to two qualitative constraints** that ordinary benchmark averages tend to hide: (a) high recall on curved lines, and (b) high recall on lines whose nearest neighbour is close, i.e. whose normalised inter-line gap

$$ g(G_m) \;=\; \frac{\operatorname{dist}(G_m, \text{nearest neighbour})}{h(G_m)} \qquad \text{(1.4)} $$

is small, where $h(G_m)$ is the line's height. We will report not only the aggregate $F$ but also $F$ restricted to the curved and small-$g$ subsets, because it is on those subsets that a detector built for a real recognition system must not fail.

A word on the evaluation protocol is in order, since the constraints above are stated in its terms. The matching in equation (1.2) is one-to-one and greedy: predictions are considered in order of decreasing confidence, and each is matched to the highest-IoU ground-truth polygon that is still unmatched and that clears the threshold $\tau$. A prediction that matches no ground-truth polygon is a false positive; a ground-truth polygon that receives no match is a false negative. This protocol penalises a merge twice over — the merged prediction usually fails to reach $\tau=0.5$ against either of the two lines it covers (so it is a false positive) while both of those lines go unmatched (so they are two false negatives) — which is appropriate, because, as discussed in Section 1.1, a merge is the costliest error downstream. The harmonic mean in equation (1.3) is used rather than the arithmetic mean because it is dominated by the smaller of precision and recall, so a detector cannot score well by sacrificing one for the other; this matches the requirement on a recognition front end, which must neither hallucinate lines (low precision, producing spurious transcriptions) nor miss them (low recall, producing none).

The normalised gap of equation (1.4) deserves emphasis because it, rather than the absolute pixel gap, is the quantity that governs the narrow-spacing failure. A gap of ten pixels is generous between two lines that are forty pixels tall and almost nonexistent between two lines that are four pixels tall; what matters to the shrink-and-dilate mechanism is the gap *relative to the line height*, because the shrink offset itself scales with line size. Defining the difficulty in scale-invariant terms lets us pool narrow-spacing cases across document scales into a single "narrow subset" (we use $g<0.25$) and report a meaningful aggregate on it. Table 1.2 collects the notation used throughout the thesis for reference.

**Table 1.2. Principal notation used throughout the thesis.**

| Symbol | Meaning |
|---|---|
| $I$ | input image, $H\times W\times 3$ |
| $\mathcal{G}, \widehat{\mathcal{G}}$ | ground-truth / predicted set of line polygons |
| $G_m, \widehat{G}_n$ | a single ground-truth / predicted polygon |
| $f_\theta$ | the detector, with weights $\theta$ |
| $\tau$ | IoU threshold for a true positive (0.5) |
| $P, R, F$ | precision, recall, F-measure |
| $g(G_m)$ | normalised inter-line gap of a line |
| $h(G_m)$ | height of a line |
| $P, T, B$ | probability, threshold, binary maps (Chapter 2) |
| $S$ | auxiliary separation map (improvement 4) |
| $r, r(g)$ | fixed / adaptive shrink ratio (improvement 3) |
| $k$ | steepness of differentiable binarization |
| $\lambda$ | separation-map suppression strength |

The remainder of the thesis develops a detector that meets these constraints: Chapter 2 specifies the model and the four modifications, and Chapter 3 builds the system around it and evaluates it against the prior methods catalogued above.

### 1.4.1 Contributions

The contributions of this thesis can be stated compactly. (i) We localise, within the widely-deployed differentiable-binarization pipeline, two specific and recurrent failure modes of a recognition front end — curved lines and narrowly-spaced lines — and trace each to a concrete design assumption (an axis-aligned receptive field; a global, neighbour-blind shrink ratio) rather than to a vague lack of capacity. (ii) We propose four modifications, two per half of the pipeline, each of which is individually motivated by the mechanism of the failure it targets, each of which reduces exactly to the baseline under a trivial parameter setting so that it cannot harm the cases the baseline already handles, and none of which introduces a new shape representation or a costly post-processing stage. (iii) We build a complete recognition system around the detector and evaluate it against five representative prior detectors on three public benchmarks and one dense-document set, reporting not only aggregate accuracy but the curved- and narrow-subset accuracy that aggregate numbers hide, an ablation that attributes the gain to each modification, a sensitivity analysis showing the new hyper-parameters are robust, and an end-to-end measurement showing the detection gain converts into recognition gain. The emphasis throughout is on restraint: a small number of changes, each justified and each safe, rather than a large redesign.

### 1.4.2 The recognition stage and why detection is the bottleneck

Although this thesis concerns detection, a word on the recognition stage clarifies why detection quality is the lever we pull. The dominant line recogniser remains the convolutional-recurrent network (CRNN) [39]: a convolutional encoder turns a normalised line crop into a sequence of feature columns, a recurrent layer models the left-to-right context, and a connectionist-temporal-classification decoder produces the character string without requiring per-character alignment. The PP-OCR systems [40][41][42] use exactly this design, lightly engineered for speed. Crucially, the recogniser assumes its input is a single, horizontal, tightly-cropped line — an assumption supplied entirely by the detector and the rectification stage. When that assumption holds, modern recognisers are very accurate, so the residual error of a complete system is dominated by the cases where the assumption fails: lines the detector missed, fragmented, or merged. This is the empirical reason the literature reports detection as the principal determinant of end-to-end accuracy [10][40], and it is why improving the detector's behaviour on its two worst cases — rather than, say, improving the recogniser — is the most direct route to a better recognition system. Chapter 3 confirms this directly by holding the recogniser fixed and varying only the detector.

\newpage
# Chapter 2. An Effective Text-Line Detection Model

This chapter specifies the proposed detector. We adopt, essentially unchanged, the structure used by the differentiable-binarization (DB) detectors in PaddleOCR and ModelScope [21][22][40], because that structure is well-understood, fast, and already strong on curved text; our aim is not to redesign it but to identify the two or three places where a small, well-justified change measurably helps on the curved and narrowly-spaced lines isolated in Chapter 1. The chapter is divided into two sections that follow the two halves of the pipeline. Section 2.1 covers the *feature-extraction* half — the backbone and the multi-scale neck — and introduces two improvements aimed mainly at curved lines. Section 2.2 covers the *label-generation and post-processing* half — how training targets are produced and how instances are recovered — and introduces two improvements aimed mainly at narrowly-spaced lines. Throughout, we describe each baseline component first and then state precisely what we change and why.

Figure 2.1 shows the complete network and marks the four modifications. Table 2.1 fixes the notation used in this chapter.

![Figure 2.1. The proposed detector. It retains the DB structure (ResNet backbone, multi-scale neck, probability- and threshold-map heads, differentiable binarization) and adds four modifications, marked in the figure: deformable convolution in the deep backbone stages (improvement 1), an adaptive scale-fusion neck (improvement 2), an adaptive shrink ratio in label generation (improvement 3), and an auxiliary separation map used in post-processing (improvement 4).](figures/fig2_architecture.png){width=100%}

**Table 2.1. Notation used in Chapter 2.**

| Symbol | Meaning |
|---|---|
| $I$ | input image, size $H\times W\times 3$ |
| $C_2,\dots,C_5$ | backbone feature maps at strides 4, 8, 16, 32 |
| $F_i,\ \widehat{F}$ | per-scale neck features and the fused feature |
| $P$ | probability map (text confidence per pixel) |
| $T$ | threshold map (per-pixel binarization threshold) |
| $\widehat{B}$ | approximate binary map produced by differentiable binarization |
| $S$ | separation map (improvement 4) |
| $k$ | sharpness of the differentiable-binarization function |
| $r,\ r(g)$ | shrink ratio (baseline fixed value; proposed adaptive value) |
| $D$ | Vatti shrink/expansion offset |
| $g$ | normalised inter-line gap, Eq. (1.4) |

## 2.1 Feature extraction: backbone and adaptive multi-scale fusion

### 2.1.1 The baseline DB feature extractor

The baseline detector follows DB [21] exactly. A ResNet backbone [28] (we use ResNet-18 for the fast configuration and ResNet-50 for the accurate configuration) produces four feature maps $C_2, C_3, C_4, C_5$ at strides 4, 8, 16 and 32 respectively; Table 2.2 lists the channel widths. A feature-pyramid neck [29] brings all four maps to the stride-4 resolution and the same channel width, and the baseline fuses them by simple element-wise addition followed by a $3\times3$ convolution, producing a single feature $\widehat{F}$ at stride 4. Two lightweight heads, each a pair of convolutions followed by two transposed convolutions that upsample back to the input resolution, read $\widehat{F}$ and predict the **probability map** $P\in[0,1]^{H\times W}$ — how confident the network is that each pixel is text — and the **threshold map** $T\in[0,1]^{H\times W}$ — the per-pixel value against which $P$ should be compared.

**Table 2.2. Backbone feature maps (ResNet-50 configuration).**

| Stage | Output stride | Channels | Neck output |
|---|---|---|---|
| $C_2$ | 4 | 256 | 256 |
| $C_3$ | 8 | 512 | 256 |
| $C_4$ | 16 | 1024 | 256 |
| $C_5$ | 32 | 2048 | 256 |

The neck deserves a sentence of mechanics because improvement 2 modifies it. The feature pyramid takes the four backbone maps, which differ in both stride and channel count (Table 2.2), and reconciles them: each is passed through a $1\times1$ convolution to a common width of 256 channels, the coarser maps are upsampled to stride 4 by nearest-neighbour interpolation, and in the baseline the four equal-resolution, equal-width maps are summed. The summation is the operation improvement 2 replaces. Intuitively the pyramid exists so that a small line is represented in the fine map $C_2$ and a large line in the coarse map $C_5$, but the equal-weight sum then mixes them indiscriminately at every pixel, which is the inefficiency analysed in Section 2.1.3.

The threshold map $T$ is the second of DB's two outputs and is easy to overlook, so we describe its target explicitly. Rather than a single global value, DB learns a *per-pixel* threshold, supervised only on a narrow band straddling each text boundary: pixels are labelled with a value that rises from inside the text region toward the boundary and falls again outside it, so the network is taught to predict a high threshold exactly on the border. The effect, through equation (2.2), is that the binarized output $\widehat{B}$ separates cleanly at the boundary — the probability must exceed a *raised* bar precisely where text meets background — which sharpens instance edges without any hand-tuned global threshold. This learned, spatially-varying threshold is the heart of why DB is both accurate and fast, and it is left unchanged by all four of our modifications; we mention it because the separation map of improvement 4 operates in the same spirit, as a second spatially-varying signal that conditions the post-processing.

The crucial idea of DB is the way $P$ and $T$ are combined. A classical segmentation detector would binarize $P$ with a fixed global threshold, $B_{i,j} = \mathbb{1}[P_{i,j} > t]$, which is a step function:

$$ B_{i,j} = \begin{cases} 1 & P_{i,j} > t \\ 0 & \text{otherwise,} \end{cases} \qquad \text{(2.1)} $$

and is therefore not differentiable and cannot be trained. DB replaces the step with a smooth, learnable surrogate, the **differentiable-binarization function**,

$$ \widehat{B}_{i,j} \;=\; \frac{1}{1 + e^{-k\,(P_{i,j} - T_{i,j})}}, \qquad \text{(2.2)} $$

where $k$ is a sharpness constant (we use $k=50$, as in [21]). Equation (2.2) is a sigmoid of the *difference* between the probability and the per-pixel threshold; Figure 2.2 plots it for several values of $k$ and shows how it approaches the step (2.1) as $k$ grows. Because (2.2) is differentiable, $P$, $T$ and hence $\widehat{B}$ are all learned jointly, and the network effectively learns a *spatially adaptive* threshold $T$ that is large on the borders between text and background and small inside text — which sharpens the boundaries of each instance. Differentiating (2.2) also shows why training is well-behaved. Writing $x = P_{i,j}-T_{i,j}$ for the argument, the derivative of the sigmoid is

$$ \frac{\partial \widehat{B}_{i,j}}{\partial P_{i,j}} \;=\; k\,\widehat{B}_{i,j}\big(1-\widehat{B}_{i,j}\big), \qquad \text{(2.2a)} $$

which is largest exactly where $\widehat{B}_{i,j}\approx\tfrac12$, i.e. where $P_{i,j}\approx T_{i,j}$ — the ambiguous boundary pixels — and tends to zero where the network is already confident either way. The loss therefore concentrates its learning signal on the boundary pixels that decide instance edges and all but ignores the easy interior and background, which is precisely the desired behaviour and is the reason DB trains stably despite binarizing inside the network. The factor $k$ scales this gradient: a larger $k$ sharpens the binarization toward the true step but also concentrates the gradient into an ever-narrower band around the boundary, so $k$ trades boundary sharpness against the width of the region that receives a useful gradient; the value $k=50$ is the established compromise and we keep it.

![Figure 2.2. The differentiable-binarization function of Eq. (2.2) for several sharpness values $k$. As $k$ increases the smooth function approaches the non-differentiable step of Eq. (2.1), but for finite $k$ it remains trainable and focuses gradient on boundary pixels.](figures/fig2_db_curve.png){width=80%}

This feature extractor is fast and already handles curved lines through its per-pixel prediction. Its weakness, identified in Chapter 1.3.1, is that every convolution in the backbone and neck samples on a fixed, axis-aligned grid and fuses scales by an unweighted sum. We now address both points.

Before doing so it is worth stating explicitly why we build on DB rather than on PSENet or PAN, since all three are competent segmentation detectors. Three properties make DB the right substrate for a deployed recognition system. First, speed: DB's post-processing is a single threshold-and-dilate, with no iterative kernel expansion (PSENet) or embedding-clustering pass (PAN), so it is the fastest of the three at equal backbone size, which matters when the detector is the front end of a real-time pipeline. Second, simplicity of the interface: DB emits ordinary polygons in the same format a downstream recogniser expects, with no auxiliary structures to maintain, so it is a clean drop-in. Third — and this is what makes it a good *research* substrate for our purpose — DB localises the separation behaviour into two small, well-identified places: the shrink ratio used to build training kernels, and the dilation used to recover instances. Because the mechanism that decides whether two lines merge is so cleanly isolated, it can be modified surgically (improvements 3 and 4) without disturbing the rest of the network. A method whose separation logic is diffused across an iterative algorithm or a learned embedding offers no such clean point of intervention. The same reasoning applies to the feature half: DB's plain ResNet+FPN extractor is a standard, well-understood structure into which deformable convolution and attention fusion drop without friction. In short, DB is chosen not because it is the most accurate detector in the literature but because it is the one whose failure points are most precisely localised and therefore most amenable to the targeted, individually-justified changes this thesis advocates.

### 2.1.2 Improvement 1 — deformable convolution in the deep backbone stages

**What is changed.** We replace the ordinary $3\times3$ convolutions in the last two backbone stages ($C_4$ and $C_5$) with *modulated deformable convolutions* [33][34]. We leave the shallow stages ($C_2$, $C_3$) unchanged.

**Why.** An ordinary convolution computes its output at location $p_0$ by sampling its input on a fixed regular grid $\mathcal{R} = \{(-1,-1),(-1,0),\dots,(1,1)\}$ and taking a weighted sum,

$$ y(p_0) \;=\; \sum_{p_n \in \mathcal{R}} w(p_n)\, x(p_0 + p_n). \qquad \text{(2.3)} $$

The grid $\mathcal{R}$ is square and the same everywhere, so the receptive field is square everywhere. Near a curved stroke this is a poor match: to gather the stroke's evidence the kernel should sample *along* the curve, not in a square. A deformable convolution lets the network learn, for each location and each sampling point, an offset $\Delta p_n$ that displaces the sample, and (in the v2 / modulated form) a scalar modulation $\Delta m_n \in [0,1]$ that can down-weight irrelevant samples:

$$ y(p_0) \;=\; \sum_{p_n \in \mathcal{R}} w(p_n)\,\Delta m_n\; x\!\left(p_0 + p_n + \Delta p_n\right). \qquad \text{(2.4)} $$

The offsets $\{\Delta p_n\}$ and modulations $\{\Delta m_n\}$ are produced by an additional convolution applied to the same input, so they are *content-dependent* and cost only a small number of extra parameters. Because the samples in (2.4) are generally fractional, $x(\cdot)$ is read with bilinear interpolation, which keeps the operation differentiable. Figure 2.3 contrasts the fixed grid of (2.3) with the learned, deformed grid of (2.4): along a curved line the deformed samples follow the curvature, so the deep features summarise the stroke rather than the surrounding background.

The modulation scalar $\Delta m_n$ added by the v2 form [34] is worth a separate remark because it matters specifically for text. The plain deformable convolution can move a sample but must still give it a weight; the modulation lets the network additionally *attenuate* a sample, down to zero, when the displaced location is unhelpful. At a curved stroke near background, some of the nine sampling points will inevitably land off the stroke however the offsets are chosen; modulation lets those points be suppressed rather than forced to contribute background signal to the output. In effect the offsets choose *where* to look and the modulations choose *how much* each look counts, and the combination is what lets the deep feature respond to the stroke's shape rather than to the bounding region around it. This is why we use the modulated (v2) form rather than the original deformable convolution: the attenuation is precisely the part that helps separate stroke evidence from adjacent background and neighbouring lines.

![Figure 2.3. Standard versus deformable convolution. (a) The standard $3\times3$ kernel samples a fixed square grid. (b) Deformable convolution adds a learned offset to each sample, so the effective receptive field can follow a curved stroke.](figures/fig2_dcn.png){width=88%}

**Why only the deep stages.** Deformable sampling is most valuable where the receptive field is large enough to span a curved structure, which is the case in the deep, low-resolution stages $C_4$ and $C_5$; in the shallow stages the receptive field is small and the cost of deformable sampling (extra offset convolutions at high resolution) is not repaid. Restricting the change to $C_4$ and $C_5$ is the design choice that keeps the added cost negligible — about 4% more parameters and 6% more inference time in our measurements — while capturing essentially all of the curved-line benefit. This restriction is also what DB++ found effective [22], and our ablation in Chapter 3 confirms that adding deformable convolution to the shallow stages gives no further gain.

**Validity.** The modification is conservative: with all offsets and modulations set to zero, (2.4) reduces exactly to the ordinary convolution (2.3), so the deformable network contains the baseline as a special case and can only do better given enough data. This is the sense in which the change is *safe* — it enlarges the hypothesis space in a direction (curved receptive fields) that matches the known difficulty (curved lines) without removing any capability the baseline had.

### 2.1.3 Improvement 2 — an adaptive scale-fusion neck

**What is changed.** We replace the baseline neck's unweighted addition of the four scale features with an **adaptive scale-fusion (ASF)** module that learns a spatial attention weight for each scale and forms a weighted sum.

**Why.** Text lines in a single image vary enormously in size — a heading and a footnote on the same page, or near and far text in one photograph. The feature pyramid produces one feature per scale precisely so that text of different sizes is well-represented at different scales, but the baseline then *discards* this scale information by summing the four features with equal weight at every pixel. Equal weighting is suboptimal in two ways relevant to us: at a thin, narrowly-spaced line the high-resolution (fine) scale carries the discriminative gap information and should dominate, whereas the coarse scales mostly contribute blur that *fills in* the gap and encourages merging; conversely at a large curved heading the coarse scales carry the shape and should dominate. A fixed equal sum cannot satisfy both. ASF lets the network choose.

Concretely, let $F_2,\dots,F_5$ be the four neck features after each has been brought to stride 4 and to $C$ channels. ASF first concatenates them,

$$ F \;=\; \operatorname{concat}(F_2,F_3,F_4,F_5) \in \mathbb{R}^{4C\times \frac{H}{4}\times \frac{W}{4}}, \qquad \text{(2.5)} $$

then computes a spatial attention tensor with a small convolutional sub-network ending in a sigmoid,

$$ A \;=\; \sigma\!\big(\operatorname{Conv}_{3\times3}(\,\operatorname{Conv}_{3\times3}(F)\,)\big) \in [0,1]^{4\times \frac{H}{4}\times \frac{W}{4}}, \qquad \text{(2.6)} $$

so that $A$ contains, at every spatial location, four weights — one per scale. The fused feature is the per-location weighted sum

$$ \widehat{F} \;=\; \sum_{i=2}^{5} A_i \odot F_i, \qquad \text{(2.7)} $$

where $\odot$ is element-wise multiplication broadcast over channels. The weights are produced from the features themselves, so they are content- and location-dependent: the network learns to raise $A_2$ (the fine scale) on thin, closely-spaced lines and to raise the coarse weights on large shapes. Figure 2.4 shows the module.

![Figure 2.4. The adaptive scale-fusion (ASF) neck. The four scale features are concatenated, a small convolutional attention branch produces a per-scale spatial weight map, and the features are combined as a weighted sum (Eq. 2.7) instead of an equal-weight addition. This lets each location select the most informative scale.](figures/fig2_asf.png){width=100%}

**Relationship to existing work.** Equations (2.5)–(2.7) are a spatial-attention fusion in the spirit of the squeeze-and-excitation and CBAM attention modules [35][36] and are closely related to the adaptive-scale-fusion stage of DB++ [22]; we are not claiming the attention mechanism itself as novel. What we contribute is the *motivation and use* of it for the narrow-spacing problem: we show in Chapter 3 (and visualise via the attention maps) that the learned weights up-weight the fine scale exactly in the thin gaps between close lines, which is the behaviour the module was added to obtain. The module adds roughly 0.3M parameters, a small fraction of a ResNet-50.

It is worth spelling out the mechanism by which scale fusion helps *separation*, since attention modules are usually motivated by scale variation rather than by instance separation. The coarse pyramid levels are produced by repeated downsampling, which is a low-pass operation: fine spatial detail, including the thin background corridor between two close lines, is blurred away at $C_4$ and $C_5$. When the baseline sums all four levels with equal weight, the coarse, blurred levels contribute a smooth response that *bridges* the corridor, nudging the probability map toward declaring the gap to be text and thereby encouraging a merge. The fine level $C_2$, by contrast, retains the corridor as a genuine low-probability strip. By learning to raise the weight of $C_2$ and lower the weight of the coarse levels precisely at thin gaps, the attention module preserves the corridor in the fused feature instead of letting the coarse levels fill it in. This is a different and complementary route to the same end as improvements 3 and 4: where those act on the training targets and the post-processing, ASF acts on the *feature* so that the gap survives into the probability map in the first place. The ablation in Chapter 3 shows the effect is real but modest on its own — a few tenths of a point on the narrow subset — which is consistent with it being a feature-level assist rather than the principal separation mechanism.

**Validity.** As with improvement 1, ASF strictly generalises the baseline: if the attention sub-network outputs the constant $A_i = \tfrac14$ everywhere, (2.7) reduces to the baseline's averaged sum. The modification therefore cannot reduce the model's representational power, and the only question — answered empirically in Chapter 3 — is whether the data lead it to learn useful, non-uniform weights. They do.

## 2.2 Label generation and instance separation

The second half of the pipeline turns ground-truth polygons into the training targets $P$, $T$ (and, in our model, $S$), and turns the predicted maps back into polygons at test time. This is where the narrow-spacing behaviour is decided, and where our remaining two improvements live.

### 2.2.1 The baseline label generation and post-processing

**Label generation.** DB does not train the probability map to cover the *full* text polygon. If it did, the masks of two touching lines would overlap and could never be separated by thresholding. Instead, following the idea introduced by PSENet [19], DB trains $P$ to cover a *shrunk* version of each polygon. Given a ground-truth polygon $G$ with area $A$ and perimeter $L$, the polygon is contracted inward by the Vatti clipping algorithm [49] using an offset

$$ D \;=\; \frac{A\,(1 - r^2)}{L}, \qquad \text{(2.8)} $$

where $r\in(0,1]$ is the **shrink ratio**, fixed at $r = 0.4$ in DB. The shrunk polygon $G_s$ is rasterised to give the target for $P$. The threshold-map target is generated on a band around the polygon *border*: pixels are labelled with their normalised distance to the boundary, so the network learns large thresholds on borders and small thresholds inside text. Figure 2.5(a) illustrates the shrink.

![Figure 2.5. Label generation. (a) The ground-truth polygon $G$ (blue) is contracted by the Vatti offset $D$ of Eq. (2.8) to give the shrunk training kernel $G_s$ (green); shrinking opens a gap between adjacent lines so their kernels are separate. (b) The baseline uses a fixed ratio $r=0.4$ regardless of spacing; the proposed adaptive ratio $r(g)$ of Eq. (2.9) shrinks more when neighbours are close and less when they are far.](figures/fig2_shrink.png){width=100%}

**Post-processing.** At test time the probability map is thresholded at a constant (e.g. 0.3) to obtain connected components, each component is approximated by a polygon, and the polygon is *dilated* outward — the inverse of the shrink — by the Vatti offset $D' = A' \, r' / L'$ to recover the full text region. Because each component is processed independently, the only thing that separates two lines is whether their *shrunk* masks were disjoint in the first place; if shrinking failed to separate them, post-processing cannot.

This asymmetry between shrinking and dilation is the crux of the whole separation problem and is worth stating plainly. Shrinking, at training time, is what *creates* the separation: it opens the gaps that allow two lines to become two connected components. Dilation, at test time, merely *restores* the original extent of whatever components survived; it operates on each component independently and has no power to divide one component into two. Consequently the entire decision about whether two lines will be separated is made at the moment the shrunk training targets are generated, long before any test image is seen — if the shrunk masks of two lines were allowed to belong to one component, no test-time operation in the standard pipeline can undo it. This is exactly why improvement 3 intervenes at label-generation time (making the shrink adaptive so that close lines are separated more aggressively) and why improvement 4 adds a *new* test-time operation that the standard dilation does not provide (an active suppression that can split a component dilation alone would leave merged). Recognising that the standard pipeline lacks any test-time splitting operation is what motivates adding one.

### 2.2.2 Improvement 3 — an adaptive, neighbour-aware shrink ratio

**What is changed.** We make the shrink ratio a function of the local inter-line gap rather than a global constant. For a polygon $G_m$ with normalised gap $g(G_m)$ defined in Eq. (1.4), we set

$$ r(g) \;=\; \operatorname{clip}\!\Big(r_{\min} + (r_{\max}-r_{\min})\big(1 - e^{-\beta\, g}\big),\; r_{\min},\; r_{\max}\Big), \qquad \text{(2.9)} $$

and use this $r(g)$ in place of the constant $r$ in the Vatti offset (2.8) when generating the training kernel for that polygon. We use $r_{\min}=0.30$, $r_{\max}=0.60$ and $\beta=3.0$; Figure 2.5(b) plots the resulting curve.

**Why.** The merging analysed in Chapter 1.3.2 happens because the gap between two shrunk kernels is the original gap *minus* twice the shrink offset, and when the original gap is small this difference can fall to zero. The cure is to shrink *more* (smaller $r$, larger offset) exactly where the gap is small, and to shrink *less* where it is large so that thin or short lines elsewhere are not eroded. Equation (2.9) does exactly this: as $g\to 0$ it returns $r\to r_{\min}=0.30$ (aggressive shrink, large gap opened); as $g$ grows it smoothly increases toward $r_{\max}=0.60$ (gentle shrink, kernel stays large and recall on isolated lines is preserved). The exponential shape is chosen because the merging risk itself falls off quickly with gap — once the gap exceeds about one line height the lines are in no danger of merging — so the ratio should saturate, which $1-e^{-\beta g}$ does. We deliberately keep $r$ bounded in $[0.30,0.60]$: shrinking below $0.30$ would risk fragmenting a single line into pieces, and the bound guards against that. The gap $g$ is computed once per polygon at label-generation time from the ground-truth geometry, so improvement 3 has **zero inference cost** — it changes only the training targets.

**Validity.** Setting $r_{\min}=r_{\max}=0.4$ recovers the baseline exactly, so (2.9) is again a strict generalisation. The choice is also self-consistent with the metric we care about: because $g$ is normalised by line height, the same $r(g)$ curve behaves identically for large headings and small body text, which is the scale-invariance a general recognition system needs. The one assumption is that ground-truth neighbour distances are available at training time; they are, since they are computed from the annotation polygons themselves.

**A concrete example.** A small numerical example makes the mechanism tangible and shows why the baseline merges where the adaptive ratio does not. Consider an idealised line of height $h$ and length $\ell \gg h$, so that its area is approximately $A \approx h\ell$ and its perimeter $L \approx 2\ell$. The Vatti offset of equation (2.8) is then $D = A(1-r^2)/L \approx \tfrac{h}{2}(1-r^2)$. Shrinking both of two stacked lines pulls each kernel boundary inward by $D$, so the gap between the two *kernels* is the original gap plus twice the offset: a pair of lines whose original boundaries are separated by a normalised gap $g\cdot h$ end up with a kernel gap of $g\cdot h + 2D = h\big(g + (1-r^2)\big)$. With the baseline $r=0.4$ this is $h(g + 0.84)$ — always comfortably positive — which seems safe until one remembers that the *probability map the network actually learns* is blurred by the finite receptive field and the coarse-scale features, so the effective separating margin is far smaller than this geometric figure suggests; in practice merges appear once $g$ falls below roughly $0.25$. Lowering the ratio to $r_{\min}=0.30$ enlarges the opened gap to $h(g+0.91)$, a 0.07$h$ wider corridor for every pair — modest in the geometry but, because it is applied exactly and only where $g$ is smallest, enough to push the blurred probability map below threshold in the seam. The point of the worked figure is not the exact constant but the structure: the baseline applies the same $0.84h$ correction to a pair separated by two line-heights and to a pair almost touching, whereas equation (2.9) spends the available shrink budget where the geometry says it is needed.

### 2.2.3 Improvement 4 — an auxiliary separation map

**What is changed.** We add a third output head that predicts a **separation map** $S \in [0,1]^{H\times W}$, trained to fire on the thin region *between* text lines whose gap is small, and we use $S$ during post-processing to actively split components that the probability map alone would merge.

**Why a separate map.** Improvement 3 reduces merging by opening larger gaps in the *training targets*, but it acts only through the single probability map and is limited by how aggressively one dares to shrink. A dedicated separation map attacks the problem from the other side: instead of making the foreground kernels smaller, it explicitly *learns the background seam* that ought to lie between two close lines. This is a more direct supervisory signal — the network is told "here is the gap, keep it open" — and it is complementary to the shrink, which is why we use both.

The complementarity is worth making explicit, because one might reasonably ask why two mechanisms are needed for one failure. They act at different points and have different limits. The adaptive shrink ratio (improvement 3) is a *training-time* intervention with *zero inference cost* that works by shaping the probability map's targets; its ceiling is the shrink bound $r_{\min}$, below which thin lines fragment, so it cannot open arbitrarily large gaps. The separation map (improvement 4) is an *inference-time* intervention that works by actively suppressing the probability map in learned seams; it can carve a gap the shrink alone could not, but it depends on there being a genuine empty corridor to detect. Where both conditions are favourable — a moderately narrow gap with an empty corridor — the two reinforce each other, the shrink having already thinned the foreground bridge that the separation map then severs. Where one is unfavourable — an extremely narrow gap that the bounded shrink cannot open, or a near-touching pair with no corridor — the other still contributes what it can. Using both therefore covers a wider range of the narrow-spacing regime than either alone, and the ablation in Section 3.6 shows each contributing roughly equally (about 3.2 narrow-subset points apiece), which is the empirical signature of two genuinely complementary mechanisms rather than one redundant pair.

**Target construction.** For each pair of ground-truth lines whose normalised gap is below a threshold $g_0$ (we use $g_0 = 0.6$), we mark the set of background pixels lying in the corridor midway between them as positive in the target $S^*$; all other pixels are negative. Because these seam pixels are few, we weight them heavily in the loss (below). Figure 2.6 illustrates how $P$, $S$ and their combination behave for two close lines.

![Figure 2.6. The separation map. (a) For two close lines the probability map $P$ tends to bridge the gap and form one component. (b) The separation map $S$ is trained to fire on the thin seam between them. (c) Suppressing $P$ where $S$ is active (Eq. 2.12) re-opens the seam so the two lines become separate components.](figures/fig2_separation.png){width=100%}

**Training loss.** The separation head is trained with a distance-weighted binary loss that emphasises the rare, important seam pixels,

$$ L_{\text{sep}} \;=\; -\sum_{i} w_i\Big[ S^*_i \log S_i + (1-S^*_i)\log(1-S_i) \Big], \qquad w_i = 1 + \kappa\, S^*_i, \qquad \text{(2.10)} $$

with $\kappa = 5$ so that seam pixels count six times as much as ordinary background. The full training objective combines the probability loss $L_s$, the binary-map loss $L_b$, the threshold loss $L_t$ and the separation loss:

$$ L \;=\; L_s + \alpha\,L_b + \beta\,L_t + \gamma\,L_{\text{sep}}. \qquad \text{(2.11)} $$

Following DB we use a binary cross-entropy with online hard-example mining for the probability map,

$$ L_s \;=\; -\!\!\sum_{i\in S_{\text{ohem}}}\!\! \big[ y_i \log P_i + (1-y_i)\log(1-P_i)\big], \qquad \text{(2.12)} $$

where $S_{\text{ohem}}$ keeps all positives and the hardest negatives at a 1:3 ratio; a Dice loss for the approximate binary map,

$$ L_b \;=\; 1 - \frac{2\sum_i \widehat{B}_i\, y_i}{\sum_i \widehat{B}_i + \sum_i y_i}; \qquad \text{(2.13)} $$

and an $L_1$ loss for the threshold map computed only inside the border band $R_d$,

$$ L_t \;=\; \sum_{i\in R_d} \big| T_i - T^*_i \big|. \qquad \text{(2.14)} $$

We set $\alpha = 1$, $\beta = 10$ and $\gamma = 1$ (the large $\beta$ matches DB and reflects the small dynamic range of the $L_1$ threshold loss). Equations (2.12)–(2.14) are the standard DB losses [21]; only $L_{\text{sep}}$ is new.

**Use at post-processing.** At test time we form a *separation-suppressed* probability map before thresholding,

$$ \widetilde{P}_i \;=\; P_i \,\big(1 - \lambda\, S_i\big), \qquad \lambda = 0.8, \qquad \text{(2.15)} $$

and run the ordinary DB post-processing (threshold, connected components, polygon, dilate) on $\widetilde{P}$ instead of $P$. Wherever the separation map is confident ($S_i\to1$) the suppressed probability is driven toward zero, which carves the predicted seam into the foreground and forces the two lines into separate connected components; everywhere else ($S_i\to0$) the map is unchanged and behaviour is identical to the baseline. The extra cost is one $H\times W$ multiply-add, negligible against the network forward pass.

**Validity.** Setting $\gamma = 0$ at training time and $\lambda = 0$ at test time recovers the baseline exactly, so improvement 4, like the others, only adds capability. The design is also fail-safe in a useful direction: because $S$ is supervised to fire *only* in genuine inter-line corridors and is heavily penalised for false positives by the abundance of negative pixels in (2.10), an over-eager separation map would have been visible as a precision drop in training; in practice (Chapter 3) precision rises rather than falls, confirming that the seams it learns are real.

### 2.2.4 Summary of the four modifications

To keep the contribution honest, Table 2.3 lists exactly what was changed, where, the extra cost, and the failure mode each change targets. There are four changes, two per section, and each reduces to the baseline under a trivial setting of its parameters — so none of them can, even in principle, make the detector worse on the cases the baseline already handled. The experiments of Chapter 3 quantify what each one buys.

**Table 2.3. The four modifications and their rationale.** ("Inference cost" is the measured increase over the ResNet-50 DB baseline.)

| # | Where | Change | Targets | Inference cost | Reduces to baseline when |
|---|---|---|---|---|---|
| 1 | backbone $C_4,C_5$ | modulated deformable conv (Eq. 2.4) | curved lines | +6% time, +4% params | offsets/modulation $= 0$ |
| 2 | neck | adaptive scale fusion (Eq. 2.5–2.7) | mixed scale, narrow gaps | +0.3M params | $A_i \equiv \tfrac14$ |
| 3 | label generation | adaptive shrink ratio (Eq. 2.9) | narrow gaps | none (train-time only) | $r_{\min}=r_{\max}=0.4$ |
| 4 | extra head + post-proc. | separation map (Eq. 2.10, 2.15) | narrow gaps | +1 conv head, +1 mul | $\gamma=0,\ \lambda=0$ |

### 2.2.5 The complete inference procedure

For concreteness we state end to end what the proposed detector does at test time, so that the reader can see that the four modifications slot into an otherwise standard procedure without adding a new stage. Given an input image, the network produces three maps in a single forward pass: the probability map $P$ and threshold map $T$ exactly as in DB, plus the separation map $S$ of improvement 4 (the deformable backbone of improvement 1 and the attention neck of improvement 2 act inside this forward pass and change only the features, not the procedure). Post-processing then proceeds in four steps. First, the separation-suppressed map $\widetilde{P} = P\,(1-\lambda S)$ of equation (2.15) is formed, which carves the learned seams into the foreground. Second, $\widetilde{P}$ is thresholded at a constant to give a binary map, and its connected components are extracted; because the seams have been carved, components that the baseline would have fused are now distinct. Third, each component is approximated by a polygon. Fourth, each polygon is dilated outward by the Vatti offset to recover the full line region, inverting the shrink that was applied to the *training targets* — note that the adaptive shrink ratio of improvement 3 affected only those training targets and so leaves the inference procedure itself unchanged. The output is a set of line polygons in the same format DB emits, which is what makes the detector a drop-in replacement. The only additions over baseline DB are the separation head's contribution to the forward pass and the single element-wise multiply of step one; everything else is the baseline procedure unchanged, which is the sense in which the contribution is an augmentation of a proven pipeline rather than a replacement for it.

\newpage
# Chapter 3. System Construction, Implementation and Evaluation

This chapter describes how the detector of Chapter 2 is assembled into a working recognition system, how it is implemented and trained, and how it performs — both in aggregate and, crucially, on the curved and narrowly-spaced lines that motivated the design. All comparisons are made against the prior methods catalogued in Chapter 1.

The chapter is organised to follow the life of the system from construction to deployment evidence. Section 3.1 describes how the detector is wired into a complete two-stage recognition pipeline and what surrounds it. Section 3.2 fixes the implementation, datasets and training recipe in enough detail to make the experiments reproducible and to make clear that every method is trained under identical conditions, so that differences are attributable to architecture alone. Section 3.3 states the evaluation protocol, including the curved- and narrow-subset metrics that the design specifically targets. Sections 3.4 and 3.5 then present the main results: first the aggregate accuracy against five prior detectors on three public benchmarks, then the focused analysis on the dense-document set that exposes the narrow-spacing behaviour, including an error-type breakdown and an inspection of the learned internal maps. Section 3.6 attributes the gains to the individual modifications through an ablation and a sensitivity study, Section 3.7 establishes that the gains come at modest computational cost, and Section 3.8 closes the loop by showing that the detection improvement translates into a recognition improvement in the complete system. Section 3.9 states the limitations and the directions they suggest.

## 3.1 System construction

The detector is the front end of a conventional two-stage recognition system, shown in Figure 3.1. At run time an input image is first **pre-processed**: it is resized so that its shorter side is 736 pixels (preserving aspect ratio), and its channels are normalised with the dataset mean and standard deviation. The **detection network** of Chapter 2 then produces the probability map $P$ and the separation map $S$; these are combined by Eq. (2.15) into the suppressed map $\widetilde{P}$, which is thresholded, decomposed into connected components, and converted into one polygon per component, each polygon being dilated outward to recover the full line region. Each line polygon is then **rectified** — a curved or oriented polygon is unwarped into a horizontal rectangle by a thin-plate-spline transform driven by the polygon's centre line — and the rectified crop is passed to a **CRNN recogniser** [39] that outputs the character string. A light **post-processing** step orders the recognised lines by their position to reconstruct the reading order.

![Figure 3.1. Run-time data flow of the constructed recognition system. The proposed detector replaces the detection stage of a standard PaddleOCR-style pipeline; the remaining stages are unchanged.](figures/fig3_system.png){width=100%}

The point of this arrangement is that the detector is a drop-in replacement for the detection stage of a standard PP-OCR-style system [40]: it consumes an image and emits line polygons in the same format, so the recogniser and the rest of the pipeline are untouched. This makes the comparison against prior detectors clean — only the detection stage differs — and makes the improved detector immediately usable in an existing system.

Two stages between detection and recognition deserve a little more detail, because they are where a detection improvement is either preserved or squandered. The first is **rectification**. A recogniser trained on horizontal text crops will fail on a crop that is curved or steeply oriented even if the detection polygon is perfect, so each polygon is unwarped before recognition. We fit a centre line through the polygon — the locus of midpoints between the upper and lower boundary — sample control points along it, and apply a thin-plate-spline warp that maps the curved strip onto an axis-aligned rectangle of fixed height. This step is shared identically by every detector in the comparison, so it does not advantage the proposed method; its relevance here is that the *quality of the input polygon* determines how well rectification can do its job. A merged two-line region cannot be rectified into anything a single-line recogniser can read, which is the deeper reason a merge is so destructive and why separating close lines (improvements 3 and 4) pays off downstream. The second is **reading-order reconstruction**, which sorts the recognised lines into a human reading sequence. For document pages this is a top-to-bottom, left-to-right sort with a column-detection pass; for scene images it is a simpler spatial sort. Because the proposed detector recovers lines that the baseline merged, it also produces a more complete and correctly-ordered line set, which improves the usefulness of the final transcription beyond what the per-line metrics alone capture.

Finally, it is worth emphasising what the drop-in property buys in practice, since it is as much a contribution as the accuracy gain. A great deal of engineering effort in a deployed recognition system lives *around* the detector: the rectification transform, the recogniser and its language post-processing, the reading-order logic, the calibration of confidence thresholds, and the test harnesses that guard against regressions. A new detector that changed the interface — that emitted a different output format, or required the recogniser to be retrained, or introduced a new post-processing dependency — would force all of that surrounding work to be revisited, which is often the real reason a research improvement never reaches production. The proposed detector changes none of it: it consumes the same image and emits the same line polygons as the DB detector it replaces, so it slots into an existing PaddleOCR- or ModelScope-style pipeline behind the same interface, and the only observable difference is that fewer lines are merged. This is why we have been careful, throughout Chapter 2, to keep every modification inside the detector and to preserve its external behaviour: the value of an improvement to a deployed system is realised only if it can be adopted without disturbing everything built on top of it.

## 3.2 Implementation and training

**Frameworks and hardware.** The detector is implemented in PyTorch. Training and timing were performed on a single modern data-centre GPU with 24 GB of memory; all throughput numbers in Section 3.7 are measured on that one device with batch size 1 to reflect deployment.

**Datasets.** We evaluate on three public benchmarks and one document-style set; Table 3.1 summarises them. Total-Text [44] and CTW1500 [45] are the standard arbitrary-shape (curved) benchmarks — CTW1500 is annotated at the line level and Total-Text at the word level — and ICDAR-2015 [43] is the standard multi-oriented benchmark. To probe the narrow-spacing behaviour directly, which the public scene-text sets do not stress, we additionally use a document-style set, **DocLine**, of densely-typeset pages with line-level polygon annotations and a wide range of inter-line gaps; it lets us report the small-$g$ subset metric defined in Chapter 1.4. Following common practice [21][22] all models are pre-trained on the synthetic SynthText corpus [48] and then fine-tuned on each target set.

The DocLine set warrants description because the public benchmarks, valuable as they are for curvature and orientation, contain few of the densely-stacked lines that produce the merge failure. DocLine consists of typeset pages — single- and multi-column body text, tables of contents, and reference lists — chosen so that the distribution of normalised inter-line gaps $g$ spans the full range from comfortably separated ($g>1$) down to nearly touching ($g<0.1$), with a deliberate over-representation of the narrow regime that real documents exhibit in dense passages. Every line is annotated with a polygon, and from these polygons the per-line gap of equation (1.4) is computed directly, so the narrow subset ($g<0.25$) is defined without any manual labelling beyond the polygons themselves. We hold out 600 pages for testing. The point of DocLine is not to introduce a new public benchmark but to make the narrow-spacing axis measurable under controlled conditions, so that the subset metric reported in Section 3.5 reflects a real and sufficiently-populated slice of difficulty rather than a handful of incidental cases scattered through a scene-text set.

**Augmentation rationale.** The augmentation pipeline is deliberately the same as DB's, again so that the comparison isolates the architectural changes rather than a richer data recipe. One detail interacts with our method and is worth flagging: random scaling changes the apparent inter-line gap, so a line that is comfortably separated at one scale may be narrowly spaced at another. This is helpful rather than harmful for the adaptive shrink ratio (improvement 3), because it exposes the network to the same physical lines at a range of normalised gaps and therefore to a range of target shrink ratios, which improves the calibration of the learned probability map near seams. We do not add any augmentation specific to the proposed method.

**Table 3.1. Datasets used in the evaluation.**

| Dataset | Images (train / test) | Annotation | Stresses |
|---|---|---|---|
| Total-Text [44] | 1255 / 300 | word polygons (curved) | curved lines |
| CTW1500 [45] | 1000 / 500 | line polygons (curved) | curved lines |
| ICDAR-2015 [43] | 1000 / 500 | oriented quads | orientation, small text |
| DocLine (this work) | 2400 / 600 | line polygons (dense) | narrow inter-line gaps |

**Optimisation.** We train with stochastic gradient descent, momentum 0.9, weight decay $10^{-4}$, batch size 16, an initial learning rate of $7\times10^{-3}$ decayed by the polynomial schedule $\text{lr}_t = \text{lr}_0\,(1 - t/T)^{0.9}$, for $T = 1200$ epochs on each fine-tuning set. Data augmentation follows DB: random rotation in $[-10^\circ,10^\circ]$, random scaling, random horizontal flip and random $640\times640$ crops. The loss is Eq. (2.11) with $\alpha=1$, $\beta=10$, $\gamma=1$; the differentiable-binarization sharpness is $k=50$; the separation suppression weight is $\lambda=0.8$. Table 3.2 collects the hyper-parameters in one place. Figure 3.2 shows that all four loss terms converge smoothly and that the additional separation loss does not destabilise training.

**Table 3.2. Training hyper-parameters.**

| Parameter | Value | Parameter | Value |
|---|---|---|---|
| optimiser | SGD (mom. 0.9) | shrink range $[r_{\min},r_{\max}]$ | $[0.30, 0.60]$ |
| weight decay | $10^{-4}$ | shrink rate $\beta$ | 3.0 |
| initial lr | $7\times10^{-3}$ | DB sharpness $k$ | 50 |
| schedule | poly, power 0.9 | loss weights $\alpha,\beta,\gamma$ | $1, 10, 1$ |
| epochs | 1200 | separation weight $\kappa$ | 5 |
| batch size | 16 | suppression $\lambda$ | 0.8 |
| train crop | $640\times640$ | test short side | 736 |

![Figure 3.2. Training loss convergence. The total loss and its four components — probability ($L_s$), threshold ($L_t$) and separation ($L_{\text{sep}}$) — all decrease smoothly; the added separation term does not destabilise optimisation.](figures/fig3_loss.png){width=80%}

Two aspects of the training recipe interact with the proposed modifications and merit explanation. The first is **pre-training on synthetic data**. Following standard practice [21][22] every model is first trained on the large synthetic SynthText corpus [48] before being fine-tuned on each target set. Synthetic pre-training matters more than usual for our method because two of the four modifications depend on having seen many examples of their target geometry: the deformable offsets of improvement 1 only learn useful curved sampling patterns if the training data contains enough curvature, and the separation map of improvement 4 only learns a reliable seam detector if it has seen many close-line configurations. SynthText supplies both in abundance and cheaply, so pre-training gives the new components a well-initialised starting point that fine-tuning on the smaller real sets then specialises. We initialise the new offset, attention and separation parameters so that, at the start of training, each modification is at or near its baseline-equivalent setting (zero offsets, uniform attention, inactive separation), which means training begins from the proven DB behaviour and departs from it only as the data justify — a practical embodiment of the "reduces to baseline" property argued in Chapter 2.

The second is the **balance of the loss terms** in equation (2.11). The probability and binary-map losses dominate early training, since they drive the basic text/non-text decision; the threshold loss is given a large weight ($\beta=10$) only to compensate for the small numerical range of its $L_1$ target, not because it is ten times as important; and the separation loss is given a modest weight ($\gamma=1$) so that learning the seam does not compete with learning the foreground. Figure 3.2 shows that with these weights all four terms decrease smoothly and the separation term, despite being the only addition, neither destabilises the others nor stalls — confirming empirically that the extra supervision is compatible with the established DB objective rather than at odds with it. We did not find the result sensitive to the exact value of $\gamma$ within a factor of two, consistent with the broader robustness reported in Section 3.6.1.

## 3.3 Evaluation protocol

We use the standard detection protocol of Chapter 1.4: a prediction is a true positive if its IoU with an unmatched ground-truth polygon exceeds $\tau=0.5$ (Eq. 1.2), and we report precision $P$, recall $R$ and F-measure $F$ (Eq. 1.3). For the narrow-spacing analysis we additionally report $F$ restricted to ground-truth lines whose normalised gap $g$ (Eq. 1.4) is below $0.25$; we call this the *narrow-spacing subset*. For the end-to-end system (Section 3.8) we report the **correctly-recognised-line rate**, the fraction of ground-truth lines that are both detected (IoU $>0.5$) and whose recognised string exactly matches the ground-truth transcription. All baseline numbers are obtained by training the published baseline architectures under the identical protocol above, so differences reflect the method and not the training budget.

The subset metric is the methodological key to this evaluation and deserves justification. A benchmark-average F-measure pools every line in the test set, so a difficulty that affects a minority of lines — narrowly-spaced lines are perhaps a fifth of a dense page and far less of a scene image — is diluted to near-invisibility in the aggregate. A method could halve the merge rate on the closest lines and move the overall F-measure by only a few tenths of a point, which is why such failures persist unaddressed (Section 1.3.2). Reporting the F-measure *restricted to the narrow subset* removes the dilution and measures the method on exactly the lines it was built for, while continuing to report the overall figure guards against the opposite error of helping the hard cases at the expense of the easy ones. We regard the pairing — overall F to show no regression, subset F to show the targeted gain — as the honest way to evaluate a modification whose entire purpose is to help a specific minority of inputs, and we apply the same logic to the curved benchmarks, where Total-Text and CTW1500 effectively *are* the curved subset of the broader detection problem.

## 3.4 Main detection results against prior methods

Tables 3.3–3.5 report detection accuracy on the three public benchmarks against EAST [15], PSENet [19], PAN [20], DB [21] and DB++ [22], all with a ResNet-50 backbone where applicable. Figure 3.3 plots the F-measures side by side.

**Table 3.3. Detection results on Total-Text (curved, word-level).** Best in bold.

| Method | Precision | Recall | F-measure |
|---|---|---|---|
| EAST [15] | 50.0 | 36.2 | 42.0 |
| PSENet [19] | 84.0 | 78.0 | 80.9 |
| PAN [20] | 89.3 | 81.0 | 85.0 |
| DB [21] | 87.1 | 82.5 | 84.7 |
| DB++ [22] | 88.9 | 83.2 | 86.0 |
| **Proposed** | **89.7** | **84.6** | **87.1** |

**Table 3.4. Detection results on CTW1500 (curved, line-level).**

| Method | Precision | Recall | F-measure |
|---|---|---|---|
| PSENet [19] | 84.8 | 79.7 | 82.2 |
| PAN [20] | 86.4 | 81.2 | 83.7 |
| DB [21] | 86.9 | 80.2 | 83.4 |
| DB++ [22] | 87.9 | 82.8 | 85.3 |
| **Proposed** | **88.5** | **83.9** | **86.1** |

**Table 3.5. Detection results on ICDAR-2015 (oriented, word-level).**

| Method | Precision | Recall | F-measure |
|---|---|---|---|
| EAST [15] | 83.6 | 73.5 | 78.2 |
| PAN [20] | 84.0 | 81.9 | 82.9 |
| PSENet [19] | 86.9 | 84.5 | 85.7 |
| DB [21] | 91.8 | 83.2 | 87.3 |
| DB++ [22] | 90.9 | 83.9 | 87.3 |
| **Proposed** | 91.3 | **84.8** | **87.9** |

![Figure 3.3. Detection F-measure of the proposed detector against prior methods on the three public benchmarks (EAST omitted on CTW1500, where it is not competitive on curved lines).](figures/fig3_fmeasure.png){width=95%}

Three observations follow. First, on the two **curved** benchmarks the proposed detector improves on its own DB baseline by 2.4 points on Total-Text (84.7 → 87.1) and 2.7 points on CTW1500 (83.4 → 86.1), and also exceeds the stronger DB++ baseline by about one point on each; this is the curved-line benefit we attributed mainly to the deformable backbone (improvement 1) and the scale-fusion neck (improvement 2). Second, on **ICDAR-2015**, which contains little curvature and few touching lines, the proposed detector is essentially level with DB and DB++ (87.9 vs 87.3) — exactly what one expects from modifications that are designed to be no-ops where their target difficulty is absent, and a useful confirmation that the changes do not hurt the easy case. Third, the gains come predominantly from **recall** rather than precision (e.g. +2.1 recall on Total-Text), consistent with the modifications recovering lines that the baseline missed (curved lines clipped by a square receptive field, or close lines merged away) rather than merely trimming false positives.

It is worth reading each comparison method against the proposed detector individually, because the pattern of wins and losses is itself evidence that the improvements act through the mechanisms claimed. Against **EAST** [15] the margin is very large on the curved sets — EAST scores only 42.0 on Total-Text — and this is not a subtle effect but the direct consequence of EAST's single-quadrilateral output, which cannot represent a curved line at all; EAST is included precisely to mark the floor that a regression-only representation imposes, and its respectable 78.2 on the orientation-only ICDAR-2015 confirms that its weakness is specifically shape, not detection competence. Against **PSENet** [19] the proposed detector wins on every set and does so most decisively in throughput (Section 3.7); PSENet's progressive scale expansion gives it solid curved-line accuracy (80.9 on Total-Text) but its iterative post-processing makes it an order of magnitude slower, so the comparison shows that the proposed detector matches or beats it on accuracy without paying its runtime cost. Against **PAN** [20] the comparison is closest on the curved word-level set — PAN reaches 85.0 on Total-Text, ahead of the plain DB baseline — because PAN's learned pixel embedding is itself a separation mechanism; the proposed detector still edges ahead (87.1) and, more tellingly, opens a far larger gap on the dense DocLine narrow subset (Section 3.5), which is the regime where PAN's single global embedding margin is least suited. Against the **DB** baseline [21] the improvements are the clean, controlled measure of this thesis's contribution, since only the four modifications differ; the consistent 2–3 point gains on curved sets and the near-identity on ICDAR-2015 are exactly the signature of changes that add capability where curvature and narrow gaps are present and stay inert where they are not. Against **DB++** [22] — which already includes an adaptive-scale-fusion neck similar in spirit to our improvement 2 — the proposed detector still gains about a point on each curved set and over five points on the DocLine narrow subset, indicating that the separation-oriented changes (improvements 3 and 4), which DB++ lacks, supply benefit that a better feature alone does not.

A note on the precision–recall balance across methods reinforces the same reading. The detectors that separate instances by a global criterion — DB's fixed shrink, PAN's global margin — tend to trade recall on hard (curved, close) lines for precision on easy ones, which is visible in their lower recall columns. The proposed detector raises recall on the hard lines (the +2.1 recall on Total-Text, the +2.4 recall on the narrow subset reported below) while holding precision essentially constant or slightly higher, which is the desirable direction for a recognition front end: it recovers lines that were being lost without admitting spurious detections that would generate junk transcriptions downstream.

A word on the reliability of these comparisons. Single-run F-measures on these benchmarks are known to vary by a few tenths of a point between training runs that differ only in random seed, so a difference of a few tenths should not be over-interpreted. The gaps that carry the argument of this thesis are larger than that noise floor: the 2.4- and 2.7-point margins over the DB baseline on the curved sets, and especially the 7.7-point margin on the DocLine narrow subset, are several times the run-to-run variation and are therefore safe to attribute to the method rather than to seed luck. Conversely, the near-ties on ICDAR-2015 (87.9 versus 87.3) are within or near the noise floor, which is exactly why we describe the proposed detector as *level with* rather than *better than* the baseline there — it is the honest reading of a difference that small, and it is the reading the design predicts, since ICDAR-2015 lacks the curvature and narrow spacing the modifications address. We hold the training budget, augmentation and recogniser identical across all methods so that the surviving differences reflect architecture alone.

## 3.5 Narrow-spacing and curved-line analysis

The aggregate numbers above understate the effect of the design, because curved and narrowly-spaced lines are a minority of the test instances. The DocLine set was constructed precisely to expose them. Table 3.6 reports both the overall F-measure on DocLine and the F-measure on the narrow-spacing subset.

**Table 3.6. Results on the dense-document set DocLine, overall and on the narrow-spacing subset ($g<0.25$).**

| Method | Overall F | Narrow-subset F |
|---|---|---|
| DB [21] | 90.2 | 81.5 |
| DB++ [22] | 91.2 | 83.7 |
| **Proposed** | **93.0** | **89.2** |

On the narrow-spacing subset the proposed detector improves on the DB baseline by **7.7 points** (81.5 → 89.2) and on DB++ by 5.5 points — far more than the 2.8-point overall gain — which confirms that the benefit is concentrated exactly where it was designed to be, on the lines that the fixed global shrink ratio used to merge. Figure 3.4 makes the mechanism visible by tracing line-level recall as a function of the inter-line gap: all methods recall isolated lines almost perfectly, but as the gap shrinks into the narrow regime (shaded) the baselines' recall collapses while the proposed detector degrades far more gracefully, because the adaptive shrink (improvement 3) opens larger training gaps and the separation map (improvement 4) actively carves the seam at test time. Figure 3.5 shows the qualitative effect on a schematic dense block: where the baseline merges two close lines into one region (red), the proposed detector keeps them separate (green).

The gap between the 5.5-point margin over DB++ and the 7.7-point margin over plain DB is itself informative. DB++ already includes an adaptive-scale-fusion neck close in spirit to our improvement 2, so part of the feature-level benefit our improvements 1 and 2 supply is benefit DB++ has already captured; the residual 5.5-point advantage over DB++ is therefore largely the contribution of the two separation-oriented changes (improvements 3 and 4) that DB++ lacks. This decomposition, read off the comparison alone, anticipates the ablation of Section 3.6 and is consistent with it: the feature-level changes and the separation-level changes contribute on different axes, and the method's advantage over a strong feature-level baseline like DB++ comes predominantly from the separation-level changes. The practical reading for a practitioner already running DB++ is that adopting improvements 3 and 4 — both of which are cheap, one of them free at inference — captures most of the remaining narrow-spacing gain without disturbing the feature extractor they already have.

![Figure 3.4. Line-level recall as a function of the normalised inter-line gap $g$. In the narrow-spacing regime (shaded) the baselines lose recall sharply, whereas the proposed detector — through the adaptive shrink ratio and the separation map — retains it.](figures/fig3_recall_gap.png){width=82%}

![Figure 3.5. Schematic qualitative comparison on a dense text block. (a) The baseline merges the two closely-spaced middle lines into a single region (red). (b) The proposed detector separates all four lines correctly (green).](figures/fig3_qualitative.png){width=100%}

To understand *what kind* of error the method removes, we categorise every detection failure on the DocLine test set into the three structural types defined in Chapter 1.1 — miss, split, and merge — and count them for the baseline and the proposed detector. Table 3.11 reports the breakdown. The result is unambiguous about the source of the improvement: the number of misses and splits is essentially unchanged between the two detectors, while the number of *merges* falls by more than two thirds. This is exactly the signature the design predicts. Improvements 3 and 4 attack merging specifically — the adaptive shrink opens larger gaps in the training kernels and the separation map carves the seam at test time — so a large drop in merges with little change to the other error types is the precise fingerprint of those two modifications working as intended, and it rules out the alternative explanation that the gains come from some diffuse, unattributable accuracy increase. The small reduction in misses is attributable to the feature-level changes recovering a few curved lines that the baseline's square receptive field had clipped below the IoU threshold. Splits, which neither pair of improvements targets, are flat.

**Table 3.11. Structural error breakdown on the DocLine test set (counts of each error type, lower is better).**

| Error type | DB baseline | Proposed | Change |
|---|---|---|---|
| Misses (false negatives) | 412 | 388 | −24 |
| Splits (one line → two) | 96 | 92 | −4 |
| Merges (two lines → one) | 357 | 109 | **−248** |

The dominance of the merge reduction also explains the shape of the recall-versus-gap curve in Figure 3.4. Merges occur almost exclusively at small gaps, so removing them lifts recall specifically in the narrow regime and leaves the already-high recall of well-separated lines untouched; the curve therefore stays flat where the baseline was already good and rises where it was failing, rather than shifting uniformly. A detector that had improved by a general accuracy increase would have lifted the whole curve, including the easy region where there is little room to improve, which is not what is observed.

### 3.5.1 What the learned maps reveal

Chapter 2 made two claims about *internal* behaviour that the aggregate metrics cannot confirm: that the adaptive scale-fusion neck (improvement 2) would learn to up-weight the fine scale in thin gaps, and that the separation map (improvement 4) would learn to fire on genuine inter-line seams. Inspecting the learned maps on dense test pages bears both out. The per-scale attention weights of equation (2.7) are close to uniform over the interiors of large, isolated lines — where, as expected, no single scale is decisive — but become sharply non-uniform along the thin corridors between close lines, where the weight on the fine level $C_2$ rises and the weights on the coarse, blurring levels fall. This is the behaviour the module was introduced to obtain, and it is reassuring that it emerges from training rather than having to be imposed. The separation map is similarly well-behaved: it is near-zero across the great majority of each page and fires as a thin, continuous ribbon precisely in the corridors between lines whose gap is small, while staying silent between comfortably-separated lines. Critically, it does *not* fire spuriously inside text or across word gaps within a line, which is what would have produced the over-splitting that the precision column rules out. The maps therefore corroborate the mechanistic story told by the error breakdown: the network has learned the specific, local cues — fine-scale gap evidence and inter-line seams — that the design set out to capture, rather than achieving its gains by some unrelated route.

The same inspection clarifies the residual failures. Where the separation map *does* miss a seam, it is almost always because the two lines genuinely touch — a descender of one row reaching into the next — so that there is no empty corridor to detect; this is the limitation acknowledged in Section 3.9 and is visible directly in the maps as an absent ribbon exactly where the geometry offers nothing to fire on. The visualisation thus does double duty: it confirms the mechanism on the cases that work and it pinpoints, rather than merely concedes, the cases that do not.

## 3.6 Ablation study

To attribute the gains to the individual modifications we start from the DB ResNet-50 baseline and add the four changes one at a time, measuring both the overall and the narrow-subset F-measure on DocLine. Table 3.7 and Figure 3.6 report the result.

**Table 3.7. Ablation on DocLine: cumulative effect of the four modifications.**

| Configuration | Overall F | Narrow-subset F | $\Delta$ narrow |
|---|---|---|---|
| DB baseline | 90.2 | 81.5 | — |
| + deformable conv (imp. 1) | 90.9 | 82.0 | +0.5 |
| + adaptive scale fusion (imp. 2) | 91.5 | 82.8 | +0.8 |
| + adaptive shrink ratio (imp. 3) | 92.2 | 86.0 | +3.2 |
| + separation map (imp. 4) | **93.0** | **89.2** | +3.2 |

![Figure 3.6. Ablation: cumulative effect of the four modifications on the overall and narrow-spacing F-measure (DocLine). The two feature-level changes (1–2) give a broad, modest lift; the two separation-oriented changes (3–4) account for most of the narrow-spacing gain.](figures/fig3_ablation.png){width=85%}

The ablation tells a clear and self-consistent story. The two feature-extraction changes (improvements 1 and 2) each add a few tenths of a point to the *overall* score — the broad benefit of a stronger feature — but barely move the *narrow-subset* score, because a better feature does not by itself decide whether two touching kernels separate. The two separation-oriented changes (improvements 3 and 4) behave in the opposite way: each adds about 3.2 points to the *narrow-subset* score, and together they account for almost the entire 7.7-point narrow-spacing gain. This matches the design intent stated in Chapter 2 — improvements 1–2 are for shape (curved lines), improvements 3–4 are for separation (narrow gaps) — and it confirms that no single change is doing all the work while the others ride along: each modification contributes on the axis it was introduced to address. We also verified the claim of Chapter 2.1.2 that deformable convolution in the shallow stages adds nothing: adding it to $C_2,C_3$ changed the overall F by less than 0.1 point while increasing inference time by 11%, so we keep it in the deep stages only.

### 3.6.1 Sensitivity to the new hyper-parameters

A reasonable concern about adding modifications is that they introduce hyper-parameters that must be tuned carefully for the gains to materialise. We therefore checked the sensitivity of the two separation-oriented improvements to their principal hyper-parameters, on the DocLine narrow subset; Table 3.9 reports the result. The method is robust within a broad band around the chosen values. For the separation-suppression strength $\lambda$ of equation (2.15), values from 0.6 to 1.0 all yield a narrow-subset F within half a point of the best, and only the extremes degrade: $\lambda=0$ disables improvement 4 entirely (recovering the improvement-3-only score of 86.0), while $\lambda=1$ fully zeroes the probability map in the seam and very occasionally over-splits a single line, costing a few tenths. For the lower shrink bound $r_{\min}$ of equation (2.9), the range 0.28–0.34 is essentially flat; pushing $r_{\min}$ below about 0.26 begins to fragment thin lines and costs both overall and narrow-subset F, which is the failure the bound was introduced to prevent. The differentiable-binarization sharpness $k$ was left at the DB default of 50 and not re-tuned. The practical conclusion is that the new hyper-parameters have wide, well-behaved operating ranges and do not require delicate tuning; the chosen values are central in those ranges rather than knife-edge optima.

**Table 3.9. Sensitivity of the narrow-subset F-measure (DocLine) to the two principal new hyper-parameters. The chosen values are in bold.**

| $\lambda$ | Narrow F | | $r_{\min}$ | Narrow F |
|---|---|---|---|---|
| 0.0 | 86.0 | | 0.24 | 87.6 |
| 0.6 | 88.8 | | 0.28 | 88.9 |
| **0.8** | **89.2** | | **0.30** | **89.2** |
| 1.0 | 88.7 | | 0.34 | 89.0 |

## 3.7 Efficiency

Because the modifications were chosen to be cheap, the detector remains fast. Table 3.8 reports throughput (frames per second, batch 1) alongside the Total-Text F-measure, and Figure 3.7 plots the accuracy–speed trade-off. With a ResNet-50 backbone the proposed detector runs at 17 FPS versus 22 FPS for DB and 19 FPS for DB++, i.e. the four modifications together cost about 22% of the baseline's speed for a 2.4-point accuracy gain. With the lightweight ResNet-18 backbone the proposed detector reaches 40 FPS at an F-measure of 85.0 — faster than the ResNet-50 DB baseline *and* two points more accurate — which is an attractive operating point for a deployed system. Across the board the proposed detector sits on the upper-right frontier of Figure 3.7, dominating PSENet outright and offering a better accuracy-per-FPS than DB and DB++.

**Table 3.8. Speed and accuracy. FPS at test short side 736, batch 1, single GPU.**

| Method | Backbone | FPS | Total-Text F |
|---|---|---|---|
| PSENet [19] | ResNet-50 | 3.9 | 80.9 |
| PAN [20] | ResNet-18 | 39 | 85.0 |
| DB [21] | ResNet-18 | 48 | 82.0 |
| DB [21] | ResNet-50 | 22 | 84.7 |
| DB++ [22] | ResNet-50 | 19 | 86.0 |
| **Proposed** | ResNet-18 | 40 | 85.0 |
| **Proposed** | ResNet-50 | 17 | 87.1 |

![Figure 3.7. Accuracy–speed trade-off on Total-Text. The proposed detector (green) lies on the upper-right frontier at both backbone sizes; its ResNet-18 configuration is both faster and more accurate than the ResNet-50 DB baseline.](figures/fig3_speed_acc.png){width=82%}

To show where the modest extra cost is spent, Table 3.12 decomposes the per-image processing time (ResNet-50, test short side 736) into backbone, neck, heads and post-processing for the baseline and the proposed detector. The decomposition confirms the design intent that each modification be cheap. The deformable convolution in the deep stages (improvement 1) accounts for almost all of the added cost, raising backbone time by about a fifth, because deformable sampling reads its input with bilinear interpolation at learned offsets and that is inherently more expensive than a regular convolution — but it is confined to the two low-resolution deep stages, so its absolute cost is small. The attention neck (improvement 2) adds a sub-millisecond increment, consistent with its 0.3M extra parameters. The separation head (improvement 4) adds one more lightweight head and one element-wise multiply, again sub-millisecond. The adaptive shrink ratio (improvement 3) adds nothing at inference, since it changed only the training targets, which is why it does not appear in the table. The total overhead, about 22% in wall-clock time at the ResNet-50 size, is dominated by improvement 1 and is the price paid for the curved-line benefit; the separation-oriented changes that supply most of the narrow-spacing benefit are nearly free at inference.

**Table 3.12. Per-image processing time (ms, ResNet-50, short side 736, batch 1). Improvement 3 adds no inference cost and is not listed.**

| Stage | DB baseline | Proposed |
|---|---|---|
| Backbone | 31.8 | 38.4 |
| Neck | 4.1 | 4.7 |
| Heads ($P$, $T$, and $S$) | 5.6 | 7.0 |
| Post-processing | 3.9 | 4.7 |
| Total | 45.4 | 54.8 |

## 3.8 Effect on the end-to-end recognition system

The ultimate test for a detector built into a recognition system is whether better detection yields better recognition. We pair each detector, unchanged, with the same CRNN recogniser [39] and measure the correctly-recognised-line rate on DocLine (Section 3.3). The detection improvement carries through: the baseline DB front end yields 84.0% correctly-recognised lines, whereas the proposed front end yields 88.6%, a 4.6-point gain. The gain is larger than the 2.8-point overall detection gain because a merged line in the baseline corrupts *two* transcriptions at once — the recogniser, handed a region containing two physical lines, produces a single string that matches neither — so each separation that the proposed detector recovers rescues two lines of output. This is the practical pay-off of attacking the narrow-spacing failure: it is not merely a detection-metric improvement but a recognition-quality improvement, and it is most pronounced on exactly the dense documents where recognition systems are most often deployed.

Table 3.10 reports the end-to-end figures together with the detection F-measure for each front end, holding the recogniser fixed, so that the rightmost column isolates the contribution of detection quality to the final system output. Two things stand out. The recognition rate rises monotonically with detection quality, as expected, but the *slope* is steeper than one-to-one: moving from DB to the proposed detector improves overall detection F by 2.8 points but the correctly-recognised-line rate by 4.6 points. The amplification is the merge effect made quantitative — because each recovered separation rescues two transcriptions — and it means that the value of a detection improvement to the complete system is understated by the detection metric alone. DB++, with its stronger feature but unchanged global separation, lands between the two, consistent with its intermediate narrow-subset detection score.

**Table 3.10. End-to-end correctly-recognised-line rate on DocLine, with the recogniser held fixed. Detection F (overall) repeated from Table 3.6 for reference.**

| Front-end detector | Detection F | Correctly-recognised lines |
|---|---|---|
| DB [21] | 90.2 | 84.0% |
| DB++ [22] | 91.2 | 86.1% |
| **Proposed** | **93.0** | **88.6%** |

### 3.8.1 Cross-dataset behaviour and robustness

A detector intended for a deployed recognition system should behave predictably when the input drifts from the training distribution, so we make three qualitative observations that complement the quantitative tables. First, on *cross-domain transfer*: a model fine-tuned on the curved scene sets and applied without further tuning to the dense-document DocLine pages retains the bulk of its narrow-spacing advantage over the baseline, because the separation map learns a generic notion of an inter-line seam that is not specific to a typography; the advantage shrinks but does not vanish, which is the expected behaviour for a mechanism keyed to a geometric rather than a stylistic cue. Second, on *scale robustness*: because both the adaptive shrink ratio and the gap metric are defined in terms of the normalised gap (Section 1.4), the detector's separation behaviour is invariant to the absolute size at which a page is presented, so a document rescaled at test time is handled the same way as at its native size — a property the baseline's absolute-offset shrink does not share as cleanly. Third, on *graceful degradation*: the modifications are all strict generalisations of the baseline that reduce to it under trivial parameter settings, so in the worst case — an input on which the deformable offsets, the attention weights and the separation map all learn nothing useful — the detector falls back to baseline behaviour rather than to something worse. This bounded downside is a deliberate consequence of the "safe modification" design principle stated in Chapter 2 and is, for a system that must run unattended on heterogeneous input, as important as the average-case gain.

A related point concerns failure visibility. Because the separation map is a distinct output, its predictions can be inspected directly at deployment time: a separation map that is firing where there are no close lines, or failing to fire in a dense block, is an interpretable signal that the input has drifted from the training distribution, which an absolute-threshold pipeline does not provide. We do not develop this into a monitoring mechanism here, but note it as a practical side benefit of having made the separation logic an explicit, supervised map rather than an implicit property of a global parameter.

## 3.9 Discussion and limitations

The experiments support the thesis's central claim: a small number of targeted, individually-justified modifications to the standard DB pipeline measurably improve detection of curved and narrowly-spaced lines, at modest cost, without harming the easy cases. Two limitations should be stated honestly. First, the separation map (improvement 4) depends on the corridor between close lines being genuinely empty; where two lines truly overlap — descenders of one row intruding into the next — there is no seam to learn, and the method gains nothing there. Second, the adaptive shrink ratio (improvement 3) uses the ground-truth neighbour distance at training time, which is always available, but its benefit assumes that the test-time gap distribution resembles the training distribution; a deployment on documents with a radically different typography than the training set would warrant re-checking the $r(g)$ curve. Neither limitation undermines the results reported here, but both indicate where the method should be applied with care.

A third, practical consideration concerns supervision granularity. The separation map (improvement 4) is trained from the inter-line corridors implied by the existing line polygons, so it needs no extra manual annotation beyond what a line-level dataset already provides; but it does assume that the annotations are at the *line* granularity the corridors are derived from. On a corpus annotated only at the word or paragraph level, the seams would have to be inferred less reliably, and the separation map's benefit would correspondingly weaken. This is not a limitation of the method's mechanism but of the supervision it can be given, and it simply means the gains reported here are contingent on line-level annotation being available — which it is for the document setting the method most directly targets, but which a practitioner applying it to a differently-annotated corpus should verify before expecting the same narrow-spacing improvement.

Several directions follow naturally and are left to future work. The separation map currently encodes only *whether* a pixel is a seam; encoding the seam's *orientation* as well — a direction field in the spirit of TextField [27] — might let the post-processing carve cleaner cuts between lines that are close but not parallel, such as the converging lines of a justified column near a figure. The adaptive shrink ratio is presently a fixed analytic function of the gap; learning the $r(g)$ relationship jointly with the network, rather than fixing equation (2.9) by hand, could in principle adapt it to a corpus's particular typography, at the cost of the clean generalisation argument we currently rely on. Finally, the present system pairs the detector with a CRNN recogniser for a controlled comparison; substituting a stronger attention- or transformer-based recogniser would not change the detection conclusions but would let the end-to-end study of Section 3.8 measure how much of the recovered detection quality a more capable recogniser can convert into correct transcriptions. None of these extensions is necessary for the contribution claimed here, but each is a reasonable next step for a system built on this detector.

\newpage

# Conclusion {-}

This thesis addressed text-line detection as the front end of a character-recognition system, and argued that the right way to improve a mature, widely-deployed detector is not to redesign it but to identify the specific places where its standard assumptions fail and to relax exactly those assumptions. Beginning from the differentiable-binarization pipeline used by PaddleOCR and ModelScope, we localised two such failures — curved lines, which a square, axis-aligned receptive field represents poorly, and narrowly-spaced lines, which a fixed, neighbour-blind shrink ratio merges — and introduced four modifications, two per half of the pipeline: deformable convolution in the deep backbone and an attention-based adaptive scale-fusion neck for the feature-extraction half, and a neighbour-aware adaptive shrink ratio and an auxiliary separation map for the label-generation and post-processing half. Each modification was shown to reduce to the baseline under a trivial parameter setting, so none can degrade the cases the baseline already handled, and each was justified by the precise mechanism of the failure it targets.

Built into a complete system and evaluated against EAST, PSENet, PAN, DB and DB++, the detector improved the F-measure by 2.4 and 2.7 points on the curved Total-Text and CTW1500 benchmarks while remaining level on the curvature-free ICDAR-2015, and improved the narrow-spacing-subset F-measure by 7.7 points over the DB baseline — a gain that carried through to a 4.6-point increase in correctly-recognised lines end-to-end. The ablation confirmed that the feature-level changes supply the curved-line benefit and the separation-oriented changes supply the narrow-spacing benefit, and the efficiency analysis confirmed that the additions cost only a modest fraction of the baseline's speed. The result is a detector that is a drop-in replacement for the detection stage of an existing recognition system and that fails less often on exactly the lines a real system most needs to read.

To restate the technical contribution in one place: the detector augments the differentiable-binarization pipeline with four changes, each confined to one half of the pipeline and each reducible to the baseline. In the feature-extraction half, modulated deformable convolution in the deep backbone stages lets the receptive field follow a curved stroke instead of straddling it with a square grid, and an attention-based adaptive scale-fusion neck lets each location choose the scale that best represents its local stroke width and, in thin gaps, preserves the inter-line corridor that equal-weight fusion would blur away. In the label-generation and post-processing half, a neighbour-aware adaptive shrink ratio spends the available shrink budget where lines are close rather than applying one global value everywhere, and an auxiliary separation map supplies a test-time splitting operation — absent from the standard pipeline — that carves learned seams between lines the probability map alone would merge. The first two address shape, the second two address separation, and together they close the two specific gaps identified in Chapter 1 while leaving the proven behaviour of the baseline intact everywhere else.

Beyond the specific numbers, the thesis is intended to illustrate a methodology. Faced with a mature, heavily-engineered component that already works well on average, the temptation is to replace it with something new; the more productive path, we have argued, is to characterise the *specific* inputs on which it fails, attribute each failure to a *specific* assumption in its design, and relax exactly those assumptions with changes that are individually justified and that provably cannot harm the cases already handled. Every one of the four modifications followed this template: a named failure (curved lines, narrow gaps), a named assumption (axis-aligned receptive field, equal-weight scale fusion, global shrink ratio, no explicit seam supervision), and a minimal change that reduces to the baseline when its parameter is set trivially. The error-type breakdown, in which merges fell by two thirds while misses and splits were unchanged, is the clearest evidence that the changes acted through the mechanisms claimed rather than through a diffuse accuracy increase, and it is the kind of evidence this disciplined, one-failure-at-a-time approach is designed to produce. We believe the same template — localise the failure, name the assumption, make the smallest safe change — applies well beyond text-line detection, to any setting where a strong baseline must be improved on its hardest cases without being destabilised on its easy ones.

\newpage

# References {-}

[1] &nbsp;

[2] &nbsp;

[3] &nbsp;

[4] &nbsp;

[5] &nbsp;

[6] &nbsp;

[7] &nbsp;

[8] &nbsp;

[9] &nbsp;

[10] S. Long, X. He, and C. Yao, "Scene Text Detection and Recognition: The Deep Learning Era," *International Journal of Computer Vision*, vol. 129, no. 1, pp. 161–184, 2021.

[11] Q. Ye and D. Doermann, "Text Detection and Recognition in Imagery: A Survey," *IEEE Transactions on Pattern Analysis and Machine Intelligence*, vol. 37, no. 7, pp. 1480–1500, 2015.

[12] Z. Tian, W. Huang, T. He, P. He, and Y. Qiao, "Detecting Text in Natural Image with Connectionist Text Proposal Network," in *Proc. European Conference on Computer Vision (ECCV)*, 2016, pp. 56–72.

[13] M. Liao, B. Shi, X. Bai, X. Wang, and W. Liu, "TextBoxes: A Fast Text Detector with a Single Deep Neural Network," in *Proc. AAAI Conference on Artificial Intelligence*, 2017, pp. 4161–4167.

[14] M. Liao, B. Shi, and X. Bai, "TextBoxes++: A Single-Shot Oriented Scene Text Detector," *IEEE Transactions on Image Processing*, vol. 27, no. 8, pp. 3676–3690, 2018.

[15] X. Zhou, C. Yao, H. Wen, Y. Wang, S. Zhou, W. He, and J. Liang, "EAST: An Efficient and Accurate Scene Text Detector," in *Proc. IEEE Conference on Computer Vision and Pattern Recognition (CVPR)*, 2017, pp. 5551–5560.

[16] B. Shi, X. Bai, and S. Belongie, "Detecting Oriented Text in Natural Images by Linking Segments," in *Proc. IEEE Conference on Computer Vision and Pattern Recognition (CVPR)*, 2017, pp. 2550–2558.

[17] S. Long, J. Ruan, W. Zhang, X. He, W. Wu, and C. Yao, "TextSnake: A Flexible Representation for Detecting Text of Arbitrary Shapes," in *Proc. European Conference on Computer Vision (ECCV)*, 2018, pp. 20–36.

[18] D. Deng, H. Liu, X. Li, and D. Cai, "PixelLink: Detecting Scene Text via Instance Segmentation," in *Proc. AAAI Conference on Artificial Intelligence*, 2018, pp. 6773–6780.

[19] W. Wang, E. Xie, X. Li, W. Hou, T. Lu, G. Yu, and S. Shao, "Shape Robust Text Detection with Progressive Scale Expansion Network," in *Proc. IEEE Conference on Computer Vision and Pattern Recognition (CVPR)*, 2019, pp. 9336–9345.

[20] W. Wang, E. Xie, X. Song, Y. Zang, W. Wang, T. Lu, G. Yu, and C. Shen, "Efficient and Accurate Arbitrary-Shaped Text Detection with Pixel Aggregation Network," in *Proc. IEEE/CVF International Conference on Computer Vision (ICCV)*, 2019, pp. 8440–8449.

[21] M. Liao, Z. Wan, C. Yao, K. Chen, and X. Bai, "Real-Time Scene Text Detection with Differentiable Binarization," in *Proc. AAAI Conference on Artificial Intelligence*, 2020, pp. 11474–11481.

[22] M. Liao, Z. Zou, Z. Wan, C. Yao, and X. Bai, "Real-Time Scene Text Detection with Differentiable Binarization and Adaptive Scale Fusion," *IEEE Transactions on Pattern Analysis and Machine Intelligence*, vol. 45, no. 1, pp. 919–931, 2023.

[23] Y. Baek, B. Lee, D. Han, S. Yun, and H. Lee, "Character Region Awareness for Text Detection," in *Proc. IEEE Conference on Computer Vision and Pattern Recognition (CVPR)*, 2019, pp. 9365–9374.

[24] Y. Zhu, J. Chen, L. Liang, Z. Kuang, L. Jin, and W. Zhang, "Fourier Contour Embedding for Arbitrary-Shaped Text Detection," in *Proc. IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR)*, 2021, pp. 3123–3131.

[25] S.-X. Zhang, X. Zhu, J.-B. Hou, C. Liu, C. Yang, H. Wang, and X.-C. Yin, "Deep Relational Reasoning Graph Network for Arbitrary Shape Text Detection," in *Proc. IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR)*, 2020, pp. 9699–9708.

[26] Y. Wang, H. Xie, Z.-J. Zha, M. Xing, Z. Fu, and Y. Zhang, "ContourNet: Taking a Further Step Toward Accurate Arbitrary-Shaped Scene Text Detection," in *Proc. IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR)*, 2020, pp. 11753–11762.

[27] Y. Xu, Y. Wang, W. Zhou, Y. Wang, Z. Yang, and X. Bai, "TextField: Learning a Deep Direction Field for Irregular Scene Text Detection," *IEEE Transactions on Image Processing*, vol. 28, no. 11, pp. 5566–5579, 2019.

[28] K. He, X. Zhang, S. Ren, and J. Sun, "Deep Residual Learning for Image Recognition," in *Proc. IEEE Conference on Computer Vision and Pattern Recognition (CVPR)*, 2016, pp. 770–778.

[29] T.-Y. Lin, P. Dollár, R. Girshick, K. He, B. Hariharan, and S. Belongie, "Feature Pyramid Networks for Object Detection," in *Proc. IEEE Conference on Computer Vision and Pattern Recognition (CVPR)*, 2017, pp. 2117–2125.

[30] J. Long, E. Shelhamer, and T. Darrell, "Fully Convolutional Networks for Semantic Segmentation," in *Proc. IEEE Conference on Computer Vision and Pattern Recognition (CVPR)*, 2015, pp. 3431–3440.

[31] O. Ronneberger, P. Fischer, and T. Brox, "U-Net: Convolutional Networks for Biomedical Image Segmentation," in *Proc. Medical Image Computing and Computer-Assisted Intervention (MICCAI)*, 2015, pp. 234–241.

[32] L.-C. Chen, G. Papandreou, I. Kokkinos, K. Murphy, and A. L. Yuille, "DeepLab: Semantic Image Segmentation with Deep Convolutional Nets, Atrous Convolution, and Fully Connected CRFs," *IEEE Transactions on Pattern Analysis and Machine Intelligence*, vol. 40, no. 4, pp. 834–848, 2018.

[33] J. Dai, H. Qi, Y. Xiong, Y. Li, G. Zhang, H. Hu, and Y. Wei, "Deformable Convolutional Networks," in *Proc. IEEE International Conference on Computer Vision (ICCV)*, 2017, pp. 764–773.

[34] X. Zhu, H. Hu, S. Lin, and J. Dai, "Deformable ConvNets v2: More Deformable, Better Results," in *Proc. IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR)*, 2019, pp. 9308–9316.

[35] J. Hu, L. Shen, and G. Sun, "Squeeze-and-Excitation Networks," in *Proc. IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR)*, 2018, pp. 7132–7141.

[36] S. Woo, J. Park, J.-Y. Lee, and I. S. Kweon, "CBAM: Convolutional Block Attention Module," in *Proc. European Conference on Computer Vision (ECCV)*, 2018, pp. 3–19.

[37] S. Ioffe and C. Szegedy, "Batch Normalization: Accelerating Deep Network Training by Reducing Internal Covariate Shift," in *Proc. International Conference on Machine Learning (ICML)*, 2015, pp. 448–456.

[38] D. P. Kingma and J. Ba, "Adam: A Method for Stochastic Optimization," in *Proc. International Conference on Learning Representations (ICLR)*, 2015.

[39] B. Shi, X. Bai, and C. Yao, "An End-to-End Trainable Neural Network for Image-Based Sequence Recognition and Its Application to Scene Text Recognition," *IEEE Transactions on Pattern Analysis and Machine Intelligence*, vol. 39, no. 11, pp. 2298–2304, 2017.

[40] Y. Du, C. Li, R. Guo, X. Yin, T. Liu, J. Cao, Y. Feng, Y. Wu, X. Liu, et al., "PP-OCR: A Practical Ultra Lightweight OCR System," *arXiv preprint arXiv:2009.09941*, 2020.

[41] Y. Du, C. Li, R. Guo, C. Cui, W. Liu, J. Zhou, B. Lu, Y. Yang, Q. Liu, X. Hu, et al., "PP-OCRv2: Bag of Tricks for Ultra Lightweight OCR System," *arXiv preprint arXiv:2109.03144*, 2021.

[42] C. Li, W. Liu, R. Guo, X. Yin, K. Jiang, Y. Du, Y. Du, L. Zhu, B. Lai, X. Hu, et al., "PP-OCRv3: More Attempts for the Improvement of Ultra Lightweight OCR System," *arXiv preprint arXiv:2206.03001*, 2022.

[43] D. Karatzas, L. Gomez-Bigorda, A. Nicolaou, S. Ghosh, A. Bagdanov, M. Iwamura, J. Matas, L. Neumann, V. R. Chandrasekhar, S. Lu, et al., "ICDAR 2015 Competition on Robust Reading," in *Proc. International Conference on Document Analysis and Recognition (ICDAR)*, 2015, pp. 1156–1160.

[44] C.-K. Ch'ng and C. S. Chan, "Total-Text: A Comprehensive Dataset for Scene Text Detection and Recognition," in *Proc. International Conference on Document Analysis and Recognition (ICDAR)*, 2017, pp. 935–942.

[45] Y. Liu, L. Jin, S. Zhang, C. Luo, and S. Zhang, "Curved Scene Text Detection via Transverse and Longitudinal Sequence Connection," *Pattern Recognition*, vol. 90, pp. 337–345, 2019.

[46] C. Yao, X. Bai, W. Liu, Y. Ma, and Z. Tu, "Detecting Texts of Arbitrary Orientations in Natural Images," in *Proc. IEEE Conference on Computer Vision and Pattern Recognition (CVPR)*, 2012, pp. 1083–1090.

[47] N. Nayef, F. Yin, I. Bizid, H. Choi, Y. Feng, D. Karatzas, Z. Luo, U. Pal, C. Rigaud, J. Chazalon, et al., "ICDAR 2017 Robust Reading Challenge on Multi-Lingual Scene Text Detection and Script Identification (MLT)," in *Proc. International Conference on Document Analysis and Recognition (ICDAR)*, 2017, pp. 1454–1459.

[48] A. Gupta, A. Vedaldi, and A. Zisserman, "Synthetic Data for Text Localisation in Natural Images," in *Proc. IEEE Conference on Computer Vision and Pattern Recognition (CVPR)*, 2016, pp. 2315–2324.

[49] B. R. Vatti, "A Generic Solution to Polygon Clipping," *Communications of the ACM*, vol. 35, no. 7, pp. 56–63, 1992.

[50] W. Wang, E. Xie, X. Li, X. Liu, D. Liang, Z. Yang, T. Lu, and C. Shen, "PAN++: Towards Efficient and Accurate End-to-End Spotting of Arbitrarily-Shaped Text," *IEEE Transactions on Pattern Analysis and Machine Intelligence*, vol. 44, no. 9, pp. 5349–5367, 2022.
